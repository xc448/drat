library(testthat)
test_check("waffle")
