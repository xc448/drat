[![Travis build status](https://travis-ci.org/JohnCoene/echarts4r.assets.svg?branch=master)](https://travis-ci.org/JohnCoene/echarts4r.assets)

# echarts4r.assets

Assets for [echarts4r](https://echarts4r.john-coene.com).

## Installation

``` r
devtools::install_github("JohnCoene/echarts4r.assets")
```

## [Documentation](http://echarts4r-assets.john-coene.com)

