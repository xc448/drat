
<!-- README.md is generated from README.Rmd. Please edit that file -->

# Fam3PRO R package

The Fam3PRO R package extends the BayesMendel R package to
multi-syndrome, multi-gene Mendelian risk prediction modeling.

## Installation

### Install Fam3PRO from source

If you are installing Fam3PRO from source and running Linux, enter the
following into the terminal:

    R CMD INSTALL Fam3PRO_X.X.X.tar.gz

For Windows, enter the following into your R console:

    install.packages("[your Fam3PRO file path]/Fam3PRO_X.X.X.zip", repos = NULL, type = "source")

where `X.X.X` corresponds to the version number you have downloaded.

## Quick-start guide

This following is a quick-start guide for basic usage of the `Fam3PRO`
package. For greater detail on model options, please refer to the other
vignettes and documentation, e.g
`vignette("building-pedigrees", package = "Fam3PRO")` or
`help(Fam3PRO)`.

The primary function in the package is the eponymous `Fam3PRO`, which
outputs the posterior carrier probabilities and future risk of cancer of
one or more probands, based on the user-supplied `pedigree` and model
specification (either `model_spec` or explicit specification of `genes`
and `cancers`).

``` r
library(Fam3PRO)
```

### Pedigree

The user must specify the `pedigree` argument as a data frame with the
following columns:

- `ID`: A numeric value; ID for each individual. There should not be any
  duplicated entries.
- `Sex`: A numeric value; `0` for female and `1` for male. Missing
  entries are not currently supported.
- `MotherID`: A numeric value; unique ID for someone’s mother.
- `FatherID`: A numeric value; unique ID for someone’s father.
- `isProband`: A numeric value; `1` if someone is a proband, `0`
  otherwise. This will be overridden by the `proband` argument in
  `Fam3PRO`, if it is specified. At least one proband should be
  specified by either the `isProband` column or `proband`. Multiple
  probands are supported.
- `CurAge`: A numeric value; the age of censoring (current age if the
  person is alive or age of death if the person is dead). Ages ranging
  from `1` to `94` are allowed.
- `isAffX`: A numeric value; the affection status of cancer `X`, where
  `X` is a `short` cancer code (see below). Affection status should be
  encoded as `1` if the individual was diagnosed, `0`otherwise. Missing
  entries are not currently supported.
- `AgeX`: A numeric value; the age of diagnosis for cancer `X`, where
  `X` is a `short` cancer code (see below). Ages ranging from `1` to
  `94` are allowed. If the individual was not diagnosed for a given
  cancer, their affection age should be encoded as `NA` and will be
  ignored otherwise.
- `isDead`: A numeric value; `1` if someone is dead, `0` otherwise.
  Missing entries are assumed to be `0`.
- `race`: A character string; expected values are `"All_Races"`,
  `"AIAN"` (American Indian and Alaska Native), `"Asian"`, `"Black"`,
  `"White"`, `"Hispanic"`, `"WH"` (white Hispanic), and `"WNH"`
  (non-white Hispanic) (see `Fam3PRO:::RACE_TYPES`). Asian-Pacific
  Islanders should be encoded as `"Asian"`. Race information will be
  used to select the cancer and death by other causes penetrances used
  in the model. Missing entries are recoded as the `unknown.race`
  argument, which defaults to `Fam3PRO:::UNKNOWN_RACE`.
- `Ancestry`: A character string; expected values are `"AJ"`, `"nonAJ"`,
  and `"Italian"` (see `Fam3PRO:::ANCESTRY_TYPES`). Ancestry information
  will be used to select the allele frequencies used in the model.
  Missing entries are recoded as the `unknown.ancestry` argument, which
  defaults to `Fam3PRO:::UNKNOWN_ANCESTRY`.
- `Twins`: A numeric value; `0` for non-identical/single births, `1` for
  the first set of identical twins/multiple births in the family, `2`
  for the second set, etc. Missing entries are assumed to be `0`.
- Prophylactic surgical history columns: as of Fam3PRO v2.0.0, there are
  two ways to encode prophylactic surgical history for mastectomies,
  hysterectomies, and oophorectomies which are explained below. These
  preventative interventions will be used to modify the cancer
  penetrances for breast, endometrial, and ovarian cancer, respectively.
  Note that in order to be considered prophylactic, mastectomies and
  oophorectomies must have been bilateral.
  - The first method has been utilized since the initial release of
    Fam3PRO and uses two list type columns:
    - `riskmod`: A character list; expected values are `"Mastectomy"`,
      `"Hysterectomy"`, and `"Oophorectomy"` (see
      `data.frame(Fam3PRO:::RISKMODS)`).
    - `interAge`: A numeric list; the age of intervention for each risk
      modifier in `riskmod`. For example,
      `riskmod = list("Mastectomy", "Hysterectomy")` and
      `interAge = {45, 60}` indicates that the individual had a
      mastectomy at age 45 and a hysterectomy at age 60. Unknown surgery
      ages should be `NA`.
  - The second method, which is only compatible with PanelPRO v1.1.0 or
    higher, uses six different numeric columns to replace the `riskmod`
    and `interAge` list type columns. This newer method makes sharing
    and storing pedigrees as .csv files easier because list type columns
    are not compatible with .csv files. The naming conventions for the
    six new columns are `riskmodX` (3 columns) and `interAgeX` (3
    columns), where “X” is one of the 3 abbreviated surgery names
    `"Mast"`, `"Ooph"`, or `"Hyst"`:
    - `riskmodX` A binary value; `1` if the surgery occurred and `0`
      otherwise.
    - `interAgeX` A numeric value; the age of the corresponding
      intervention for `riskmodX`. For example, if `riskmodMast = 1` and
      `interAgeMast = 45` the individual had a bilateral prophylactic
      mastectomy at age 45. Unknown surgery ages should be coded as
      `NA`.
- There can be optional columns for germline testing results
  (e.g. `BRCA1`, `MLH1`) or tumor marker testing results. `ER`, `PR`,
  `CK14`, `CK5.6` and `HER2` are tumor markers associated with breast
  cancer that will modify the likelihood of phenotypes associated with
  `BRCA1` and `BRCA2`. `MSI` is a tumor marker for colorectal cancer
  that will modify the likelihoods associated with `MLH1`, `MSH2` `MSH6`
  and `PMS2`. For each of these optional columns, positive results
  should be coded as `1`, negative results should be coded as `0`, and
  unknown results should be coded as `NA`.
- There are optional columns related to breast cancer which provide more
  accurate estimates for contralateral breast cancer risk. These columns
  are:
  - `FirstBCType`: Breast cancer type of the first primary breast
    cancer. The only options are `Invasive` for pure invasive and
    `Invasive_DCIS` for mixed invasive and DCIS. There is no option for
    pure DCIS (see “Additional Notes” section). Use `NA` if no first
    primary breast cancer or unknown type.
  - `AntiEstrogen`: Anti-estrogen therapy used to treat first primary
    breast cancer. The options are `0` for no, `1` for yes, and `NA` for
    unknown or for those never diagnosed with breast cancer.
  - `HRPreneoplasia`: History of high risk preneoplasia (ie atypical
    hyperplasia or LCIS). The options are `0` for no, `1` for yes, and
    `NA` for unknown or for those never diagnosed with breast cancer.
  - `BreastDensity`: BI-RADS breast density descriptor. The options are
    the letters `a` through `d`. `a` = almost entirely fatty, `b` =
    scattered areas of fibroglandular density, `c` = heterogeneously
    dense, and `d` = extremely dense. If the breast density is unknown,
    use `NA`.
  - `FirstBCTumorSize`: Size category of the first primary breast cancer
    tumor. The only options are `"T0/T1/T2"`, `"T3/T4"`, `"Tis"`. Use
    `NA` for unknown tumor size or if there was no first primary breast
    cancer.

To represent a cancer in `pedigree`, we need to use `short` cancer
codes:

``` r
data.frame(Fam3PRO:::CANCER_NAME_MAP)
#>    short                long
#> 1    BRA               Brain
#> 2     BC              Breast
#> 3    COL          Colorectal
#> 4   ENDO         Endometrial
#> 5    GAS             Gastric
#> 6    KID              Kidney
#> 7   LEUK            Leukemia
#> 8   MELA            Melanoma
#> 9     OC             Ovarian
#> 10   OST        Osteosarcoma
#> 11  PANC            Pancreas
#> 12  PROS            Prostate
#> 13    SI     Small Intestine
#> 14   STS Soft Tissue Sarcoma
#> 15   THY             Thyroid
#> 16    UB     Urinary Bladder
#> 17   HEP       Hepatobiliary
#> 18   CBC       Contralateral
```

For example, `BC` is the `short` name that maps to `Breast`, so breast
cancer affection status and age of diagnosis should be recorded as
columns named `isAffBC` and `AgeBC`.

Note `Contralateral` indicates contralateral breast cancer (`CBC`).

Unknown values in `pedigree` should be explicitly coded as `NA`.

Before computing anything, the `Fam3PRO` function will check the
validity and structural consistency of `pedigree`. Errors will be
corrected when possible, or the function will halt with an informative
error message if not.

The `Fam3PRO` package comes with several sample pedigrees, each of which
contains family history information. For example, `err_fam_1` is a
pedigree that will fail the validity checks and `test_fam_1` is a valid
pedigree that contains 19 relatives and family history for breast and
ovarian cancer:

``` r
head(test_fam_1)
#>   ID Sex MotherID FatherID isProband CurAge isAffBC
#> 1  1   0       NA       NA         0     93       1
#> 2  2   1       NA       NA         0     80       0
#> 3  3   0        1        2         0     72       1
#> 4  4   1        1        2         0     65       0
#> 5  5   1        1        2         0     65       0
#> 6  6   0        1        2         1     55       0
#>   isAffOC AgeBC AgeOC isDead      race      riskmod
#> 1       0    65    NA      1 All_Races             
#> 2       0    NA    NA      1 All_Races             
#> 3       1    40    NA      0 All_Races   Mastectomy
#> 4       0    NA    NA      1 All_Races             
#> 5       0    NA    NA      0 All_Races             
#> 6       0    NA    NA      0 All_Races Hysterectomy
#>   interAge Twins BRCA1 BRCA2 ER CK5.6 CK14 PR HER2
#> 1              0    NA    NA NA    NA   NA NA   NA
#> 2              0     1     0 NA    NA   NA NA   NA
#> 3       28     0    NA    NA NA    NA   NA NA   NA
#> 4              1     1    NA NA    NA   NA NA   NA
#> 5              1    NA    NA NA    NA   NA NA   NA
#> 6       48     0    NA    NA  0    NA   NA NA   NA
#>   Ancestry
#> 1    nonAJ
#> 2    nonAJ
#> 3       AJ
#> 4    nonAJ
#> 5    nonAJ
#> 6    nonAJ
```

For more information on the sample pedigrees, see their individual help
pages. For an example of building a pedigree, see the vignette on
“Building Fam3PRO Pedigrees”.

### Model specification

There are a few ways to specify the model to be run by `Fam3PRO`. The
first is to pass a character string to `model_spec` that indicates a
pre-specified model. Available options are:

``` r
names(Fam3PRO:::MODELPARAMS)
#> [1] "PanPRO11" "PanPRO22"
```

The genes and cancers that these models specify can be found by
accessing the named list element in `Fam3PRO:::MODELPARAMS`. For
example, the 22 genes and 17 cancers specified by `"PanPRO22"` are:

``` r
Fam3PRO:::MODELPARAMS$PanPRO22
#> $GENES
#>  [1] "ATM"    "BARD1"  "BRCA1"  "BRCA2"  "BRIP1"  "CDH1"  
#>  [7] "CDK4"   "CDKN2A" "CHEK2"  "EPCAM"  "MLH1"   "MSH2"  
#> [13] "MSH6"   "MUTYH"  "NBN"    "PALB2"  "PMS2"   "PTEN"  
#> [19] "RAD51C" "RAD51D" "STK11"  "TP53"  
#> 
#> $CANCERS
#>  [1] "Brain"               "Breast"             
#>  [3] "Colorectal"          "Endometrial"        
#>  [5] "Gastric"             "Kidney"             
#>  [7] "Leukemia"            "Melanoma"           
#>  [9] "Ovarian"             "Osteosarcoma"       
#> [11] "Pancreas"            "Prostate"           
#> [13] "Small Intestine"     "Soft Tissue Sarcoma"
#> [15] "Thyroid"             "Urinary Bladder"    
#> [17] "Hepatobiliary"       "Contralateral"
```

For convenience, the `Fam3PRO` package exports wrapper functions for all
of the pre-specified models: `Fam3PRO11`, and `Fam3PRO22`.

Alternatively, the user can explicitly pass in genes to the `genes`
argument and cancers to the `cancers` argument. If the inputs conflict
with each other, `genes` and `cancers` will override the `model_spec`
specification. Available genes are:

``` r
Fam3PRO:::GENE_TYPES
#>  [1] "ATM"    "BARD1"  "BRCA1"  "BRCA2"  "BRIP1"  "CDH1"  
#>  [7] "CDK4"   "CDKN2A" "CHEK2"  "EPCAM"  "MLH1"   "MSH2"  
#> [13] "MSH6"   "MUTYH"  "NBN"    "PALB2"  "PMS2"   "PTEN"  
#> [19] "RAD51C" "RAD51D" "STK11"  "TP53"
```

Available cancers are:

``` r
Fam3PRO:::CANCER_TYPES
#>  [1] "Brain"               "Breast"             
#>  [3] "Colorectal"          "Endometrial"        
#>  [5] "Gastric"             "Kidney"             
#>  [7] "Leukemia"            "Melanoma"           
#>  [9] "Ovarian"             "Osteosarcoma"       
#> [11] "Pancreas"            "Prostate"           
#> [13] "Small Intestine"     "Soft Tissue Sarcoma"
#> [15] "Thyroid"             "Urinary Bladder"    
#> [17] "Hepatobiliary"       "Contralateral"
```

Therefore, it is equivalent to run:

- `Fam3PRO(pedigree, model_spec = "PanPRO22", ...)`
- `Fam3PRO22(pedigree, ...)`
- `Fam3PRO(pedigree, genes = Fam3PRO:::MODELPARAMS$PanPRO22$GENES, cancers = Fam3PRO:::MODELPARAMS$PanPRO22$CANCERS, ...)`

By default, `Fam3PRO` without any user-specified `model_spec`, `genes`,
or `cancers` will run `Fam3PRO22`, so it is also equivalent in this case
to simply write `Fam3PRO(pedigree, ...)`. Cancers for which no family
history is available in the pedigree will be dropped from the model
specification, under the default settings.

### Additional notes

- The `Fam3PRO` function pulls model parameters, including mutation
  allele frequencies and cancer penetrances, from the `database`
  argument. The internal `Fam3PRODataBase` is used by default, but users
  can override it by passing in their own database.

- The optional `proband` argument allows the user to specify the IDs for
  one or more probands for whom carrier probabilities and future risk
  should be estimated, overriding the contents of the `isProband` column
  in `pedigree`. If `proband = "All"`, the results for all individuals
  in the pedigree will be calculated.

- The `Fam3PRO` function returns a list with two elements,
  `posterior.prob` and `future.risk`. By default, `Fam3PRO` imputes 20
  iterations of missing ages (`impute.missing.ages = TRUE` and
  `iterations = 20`). When missing ages are multiply imputed,
  `posterior.prob` and `future.risk` report the average and range of the
  results from these imputations.

- The `max.mut` argument sets the maximum number of simultaneous
  mutations allowed. By default, `max.mut` will be set to `2` when
  `pedigree` has 30 or fewer members and `1` when `pedigree` exceeds 30
  members. For example, if `max.mut = 2`, a model that includes MLH1,
  MSH2, and MSH6 will estimate the carrier probability of being a
  carrier of both MLH1 and MSH2 (or of both MLH1 and MSH6, or of both
  MSH2 and MSH6), but not of being a carrier of MLH1, MSH2, and MSH6
  simultaneously. Choosing a large value for `max.mut`, especially when
  there is a large number of genes in the model, may result in slow
  performance.

- The `age.by` argument determines the fixed age intervals for the
  future risk calculations. By default, `age.by = 5`, so if the
  proband’s current age is 30, future risk will be calculated at ages
  35, 40, 45, etc.

- All breast cancers are assumed to be invasive or mixed invasive and
  DCIS. Pure DCIS breast cancers are not compatible with Fam3PRO.

### Example usage

The following example demonstrates how to fit a custom model to the
test_fam_1 pedigree using Fam3PRO. In this example, we specify a set of
genes and cancers to estimate the posterior carrier probabilities and
future risk for the proband (the individual with ID 6, as identified in
test_fam_1 where isProband == 1).

``` r
out1 <- Fam3PRO(
  pedigree = test_fam_1, 
  genes = c("BRCA1", "BRCA2"),       
  cancers = c("Breast", "Ovarian")  
)
#> Your model has 2 cancers - Breast, Ovarian and 2 genes - BRCA1_hetero_anyPV, BRCA2_hetero_anyPV.
#> Setting max.mut to 2.
#> ID 6,29 has tumor marker testing results but is unaffected for relevant cancer, so testing will be ignored.
#> Germline testing results for BRCA1 are assumed to be for default variant BRCA1_hetero_anyPV.
#> Germline testing results for BRCA2 are assumed to be for default variant BRCA2_hetero_anyPV.
#> ID 3 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 10 's race has been changed to All_Races to meet hereditary consistency.
#> ID 9 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 16,17 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 29,30 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 33,34 's race has been changed to All_Races to meet hereditary consistency.
#> ID 33,34 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 6's lower and upper bounds for the probability of carrying any pathogenic variant are (0.30539, 0.30544).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

``` r

# Display the results
print(out1)
#> $posterior.prob
#> $posterior.prob$`6`
#>                                   genes
#> 1                            noncarrier
#> 2                    BRCA1_hetero_anyPV
#> 3                    BRCA2_hetero_anyPV
#> 4 BRCA1_hetero_anyPV.BRCA2_hetero_anyPV
#>       estimate        lower
#> 1 0.6945917127 0.6945597677
#> 2 0.3042379832 0.3042239757
#> 3 0.0008244515 0.0008041947
#> 4 0.0003458526 0.0003373554
#>          upper
#> 1 0.6946116976
#> 2 0.3042467523
#> 3 0.0008568245
#> 4 0.0003594321
#> 
#> 
#> $future.risk
#> $future.risk$`6`
#> $future.risk$`6`$Breast
#>   ByAge   estimate      lower
#> 1    60 0.04683603 0.04683248
#> 2    65 0.09299212 0.09298578
#> 3    70 0.13677404 0.13676562
#> 4    75 0.17505519 0.17504529
#> 5    80 0.20623683 0.20622582
#> 6    85 0.22914480 0.22913300
#> 7    90 0.24223350 0.24222129
#>        upper
#> 1 0.04684169
#> 2 0.09300225
#> 3 0.13678748
#> 4 0.17507101
#> 5 0.20625442
#> 6 0.22916366
#> 7 0.24225303
#> 
#> $future.risk$`6`$Ovarian
#>   ByAge   estimate      lower
#> 1    60 0.03585963 0.03585849
#> 2    65 0.07157810 0.07157567
#> 3    70 0.10420462 0.10420089
#> 4    75 0.13183601 0.13183112
#> 5    80 0.15459669 0.15459089
#> 6    85 0.17112517 0.17111879
#> 7    90 0.17888222 0.17887561
#>        upper
#> 1 0.03586145
#> 2 0.07158199
#> 3 0.10421058
#> 4 0.13184383
#> 5 0.15460597
#> 6 0.17113537
#> 7 0.17889279
```

The `visRisk` function provides interactive visualizations for exploring
the proband(s)’s carrier probabilities and future risk estimates
returned by `Fam3PRO`. For example,

``` r
visRisk(out1)
```

<figure>
<img src="man/figures/ans2.png" alt="vis_risk" />
<figcaption aria-hidden="true">vis_risk</figcaption>
</figure>

## Example: Using the `Fam3PRO` Function with `use.mult.variants`

The `Fam3PRO` function is a powerful tool for calculating cancer risk
based on family pedigree information. In some cases, individuals may
carry multiple genetic variants within the same gene (e.g., BRCA1,
BRCA2). By default, the model only considers a single variant per gene.
However, you can set the parameter `use.mult.variants = TRUE` to include
all available variants for more detailed risk assessments.

The following example demonstrates how to use the `Fam3PRO` function
with `use.mult.variants = TRUE`. This will allow the model to consider
multiple variants within the specified genes, providing a more
comprehensive risk estimate.

``` r
out2 <- Fam3PRO(
  pedigree = test_fam_1, 
  genes = c("BRCA1", "BRCA2"),       
  cancers = c("Breast", "Ovarian"),
  use.mult.variants = TRUE
)
#> Your model has 2 cancers - Breast, Ovarian and 2 genes - BRCA1_hetero_BCCR, BRCA1_hetero_OCCR, BRCA1_hetero_other, BRCA2_hetero_BCCR, BRCA2_hetero_OCCR, BRCA2_hetero_other, including 2 genes with multiple variants - BRCA1, BRCA2.
#> Setting max.mut to 2.
#> ID 6,29 has tumor marker testing results but is unaffected for relevant cancer, so testing will be ignored.
#> Germline testing results for BRCA1 are assumed to be for default variant BRCA1_hetero_anyPV.
#> Germline testing results for BRCA2 are assumed to be for default variant BRCA2_hetero_anyPV.
#> ID 3 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 10 's race has been changed to All_Races to meet hereditary consistency.
#> ID 9 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 16,17 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 29,30 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 33,34 's race has been changed to All_Races to meet hereditary consistency.
#> ID 33,34 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 6's lower and upper bounds for the probability of carrying any pathogenic variant are (0.13332, 0.24218).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

``` r

# Display the results
print(out2)
#> $posterior.prob
#> $posterior.prob$`6`
#>                                    genes
#> 1                             noncarrier
#> 2                      BRCA1_hetero_BCCR
#> 3                      BRCA1_hetero_OCCR
#> 4                     BRCA1_hetero_other
#> 5                      BRCA2_hetero_BCCR
#> 6                      BRCA2_hetero_OCCR
#> 7                     BRCA2_hetero_other
#> 8    BRCA1_hetero_BCCR.BRCA2_hetero_BCCR
#> 9    BRCA1_hetero_OCCR.BRCA2_hetero_BCCR
#> 10  BRCA1_hetero_other.BRCA2_hetero_BCCR
#> 11   BRCA1_hetero_BCCR.BRCA2_hetero_OCCR
#> 12   BRCA1_hetero_OCCR.BRCA2_hetero_OCCR
#> 13  BRCA1_hetero_other.BRCA2_hetero_OCCR
#> 14  BRCA1_hetero_BCCR.BRCA2_hetero_other
#> 15  BRCA1_hetero_OCCR.BRCA2_hetero_other
#> 16 BRCA1_hetero_other.BRCA2_hetero_other
#>        estimate        lower
#> 1  7.777147e-01 7.578157e-01
#> 2  4.961821e-02 3.225014e-02
#> 3  1.688975e-02 1.124970e-02
#> 4  7.123692e-02 4.784076e-02
#> 5  1.625629e-02 7.581124e-03
#> 6  2.956648e-02 1.496569e-02
#> 7  3.856081e-02 1.858924e-02
#> 8  1.238089e-05 7.949389e-06
#> 9  5.039648e-06 3.523702e-06
#> 10 1.910509e-05 1.266197e-05
#> 11 1.734155e-05 1.151037e-05
#> 12 6.663725e-06 4.670263e-06
#> 13 2.613476e-05 1.787470e-05
#> 14 2.396041e-05 1.555825e-05
#> 15 9.551973e-06 6.740402e-06
#> 16 3.666057e-05 2.455263e-05
#>           upper
#> 1  8.666835e-01
#> 2  6.015791e-02
#> 3  2.208940e-02
#> 4  8.884784e-02
#> 5  2.227227e-02
#> 6  3.808505e-02
#> 7  5.144002e-02
#> 8  1.454487e-05
#> 9  6.386012e-06
#> 10 2.308785e-05
#> 11 2.076242e-05
#> 12 8.578664e-06
#> 13 3.215025e-05
#> 14 2.828398e-05
#> 15 1.214591e-05
#> 16 4.449435e-05
#> 
#> 
#> $future.risk
#> $future.risk$`6`
#> $future.risk$`6`$Breast
#>   ByAge   estimate      lower
#> 1    60 0.04055865 0.03023922
#> 2    65 0.08138251 0.06180715
#> 3    70 0.12170572 0.09423496
#> 4    75 0.15907053 0.12497295
#> 5    80 0.19185034 0.15161285
#> 6    85 0.21944794 0.17316164
#> 7    90 0.24080467 0.18894139
#>        upper
#> 1 0.04253974
#> 2 0.08527476
#> 3 0.12728761
#> 4 0.16604556
#> 5 0.20011070
#> 6 0.22899418
#> 7 0.25154899
#> 
#> $future.risk$`6`$Ovarian
#>   ByAge   estimate      lower
#> 1    60 0.02048635 0.01339041
#> 2    65 0.04215148 0.02745999
#> 3    70 0.06343350 0.04121916
#> 4    75 0.08323828 0.05399959
#> 5    80 0.10154175 0.06581962
#> 6    85 0.11757284 0.07616304
#> 7    90 0.12887026 0.08346186
#>        upper
#> 1 0.02392209
#> 2 0.04892385
#> 3 0.07320056
#> 4 0.09555073
#> 5 0.11612214
#> 6 0.13418416
#> 7 0.14692768
```

``` r
visRisk(out2)
```

<figure>
<img src="man/figures/ans3.png" alt="vis_risk" />
<figcaption aria-hidden="true">vis_risk</figcaption>
</figure>

`Fam3PRO11` runs an 11 gene, 11 cancer model. `test_fam_2` is a more
complex pedigree with 25 relatives and information on endometrial,
pancreatic, and small intestine cancer. By default, the cancers that are
not included in the pedigree will be dropped from the model
specification. Carrier probabilities will therefore be estimated based
on family history of endometrial, pancreatic, and small intestine
cancer; future risk estimates will only be given for these three
cancers.

``` r
out3 <- Fam3PRO11(pedigree = test_fam_2)
#> Brain, Breast, Colorectal, Gastric, Kidney, Melanoma, Ovarian, Prostate, Contralateral cancer(s) not in pedigree, so they will be removed from the model specification.
#> Your model has 3 cancers - Endometrial, Pancreas, Small Intestine and 11 genes - BRCA1_hetero_anyPV, BRCA2_hetero_anyPV, ATM_hetero_anyPV, PALB2_hetero_anyPV, EPCAM_hetero_anyPV, PMS2_hetero_anyPV, MLH1_hetero_anyPV, MSH2_hetero_anyPV, MSH6_hetero_anyPV, CDKN2A[P16]_hetero_anyPV.
#> Setting max.mut to 2.
#> ID 12's lower and upper bounds for the probability of carrying any pathogenic variant are (0.18359, 0.26504).
#> ID 19's lower and upper bounds for the probability of carrying any pathogenic variant are (0.10457, 0.1466).
#> ID 21's lower and upper bounds for the probability of carrying any pathogenic variant are (0.04486, 0.04815).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

`out3` contains results for the three probands specified by the
`isProband` column in `fam25`. We can extract the results for a specific
proband, e.g. the one with `ID = 12`.

``` r
head(out3$posterior.prob$`12`)
#>                genes     estimate
#> 1         noncarrier 7.865484e-01
#> 2 BRCA1_hetero_anyPV 9.710081e-04
#> 3 BRCA2_hetero_anyPV 1.095702e-03
#> 4   ATM_hetero_anyPV 3.119200e-03
#> 5 PALB2_hetero_anyPV 9.248660e-04
#> 6 EPCAM_hetero_anyPV 1.850897e-05
#>          lower        upper
#> 1 7.349587e-01 8.164098e-01
#> 2 9.505986e-04 9.927828e-04
#> 3 1.071286e-03 1.121795e-03
#> 4 3.053583e-03 3.188884e-03
#> 5 9.042598e-04 9.469008e-04
#> 6 1.813198e-05 1.888302e-05
```

``` r

out3$future.risk$`12`
#> $Endometrial
#>    ByAge   estimate       lower
#> 1     49 0.01142447 0.009729645
#> 2     54 0.03260254 0.027726733
#> 3     59 0.06046886 0.051574640
#> 4     64 0.08304290 0.071393643
#> 5     69 0.09483359 0.082475206
#> 6     74 0.10150689 0.089197231
#> 7     79 0.10611686 0.093902117
#> 8     84 0.10921176 0.097063039
#> 9     89 0.11092063 0.098812030
#> 10    94 0.11178311 0.099701252
#>         upper
#> 1  0.01444102
#> 2  0.04128998
#> 3  0.07629808
#> 4  0.10368059
#> 5  0.11655261
#> 6  0.12297034
#> 7  0.12729764
#> 8  0.13020582
#> 9  0.13180937
#> 10 0.13261526
#> 
#> $Pancreas
#>    ByAge     estimate        lower
#> 1     49 0.0005139685 0.0004638275
#> 2     54 0.0013459773 0.0012242108
#> 3     59 0.0027573403 0.0025190302
#> 4     64 0.0049793237 0.0045574439
#> 5     69 0.0080808216 0.0074157746
#> 6     74 0.0116471047 0.0107407032
#> 7     79 0.0152545605 0.0141746497
#> 8     84 0.0183679705 0.0172068843
#> 9     89 0.0206937153 0.0195187429
#> 10    94 0.0222370446 0.0210897349
#>           upper
#> 1  0.0006043847
#> 2  0.0015651886
#> 3  0.0031864078
#> 4  0.0057395155
#> 5  0.0092796518
#> 6  0.0132805488
#> 7  0.0171987082
#> 8  0.0204561311
#> 9  0.0228054203
#> 10 0.0242995090
#> 
#> $`Small Intestine`
#>    ByAge    estimate       lower
#> 1     49 0.001447946 0.001204529
#> 2     54 0.003248391 0.002718037
#> 3     59 0.005300019 0.004465702
#> 4     64 0.007512243 0.006365159
#> 5     69 0.009650381 0.008213919
#> 6     74 0.011552878 0.009865645
#> 7     79 0.013002945 0.011130493
#> 8     84 0.014019370 0.012024273
#> 9     89 0.014519555 0.012475757
#> 10    94 0.014679913 0.012633244
#>          upper
#> 1  0.001887493
#> 2  0.004202854
#> 3  0.006792199
#> 4  0.009554215
#> 5  0.012201025
#> 6  0.014547235
#> 7  0.016330290
#> 8  0.017569054
#> 9  0.018157794
#> 10 0.018323690
```

Finally, we can run Fam3PRO-22 (the default for `Fam3PRO`) on
`test_fam_3`, which has 50 relatives and stores family history for the
11 cancers specified by Fam3PRO-11. Note that because there are more
than 30 relatives in `test_fam_3`, the `max.mut` argument, which sets
the maximum number of simultaneous mutations allowed, defaults to `1`
instead of `2`. We set `proband = 10`, overriding the proband
information encoded in `test_fam_3$isProband`.

``` r
out4 <- Fam3PRO(pedigree = test_fam_3, proband = 10)
#> Leukemia, Osteosarcoma, Soft Tissue Sarcoma, Thyroid, Urinary Bladder, Hepatobiliary, Contralateral cancer(s) not in pedigree, so they will be removed from the model specification.
#> Your model has 11 cancers - Brain, Breast, Colorectal, Endometrial, Gastric, Kidney, Melanoma, Ovarian, Pancreas, Prostate, Small Intestine and 22 genes - ATM_hetero_anyPV, BARD1_hetero_anyPV, BRCA1_hetero_anyPV, BRCA2_hetero_anyPV, BRIP1_hetero_anyPV, CDH1_hetero_anyPV, CDK4_hetero_anyPV, CDKN2A[P16]_hetero_anyPV, EPCAM_hetero_anyPV, MLH1_hetero_anyPV, MSH2_hetero_anyPV, MSH6_hetero_anyPV, MUTYH_hetero_anyPV, MUTYH_homo_anyPV, PALB2_hetero_anyPV, PMS2_hetero_anyPV, PTEN_hetero_anyPV, RAD51C_hetero_anyPV, RAD51D_hetero_anyPV, STK11_hetero_anyPV, TP53_hetero_anyPV.
#> Setting max.mut to 1.
#> `proband` argument does not match with "isProband" column in the pedigree, using `proband`
#> Riskmods that are NA will be removed
#> Warning: ID 14 is male but has been
#> affected by OC; turning into
#> non-affection.
#> ID 10's lower and upper bounds for the probability of carrying any pathogenic variant are (0.92862, 0.9791).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

### Example: Handling Pedigrees with Loops using breakloop

n some cases, a pedigree may contain loops (cycles), where individuals
are related in complex ways that form circular references. These loops
can complicate genetic risk calculations. The `Fam3PRO` function
includes an option to automatically detect and break loops in pedigrees
using the breakloop parameter. This example demonstrates how to use this
feature.

Consider the following pedigree (`errfam1`), which includes a loop:

``` r
errfam1 <- data.frame(
          'ID' = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11),
          'Sex' = c(0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0),
          'MotherID' = c(NA, NA, 1, 1, NA, NA, 5, 5, 5, 7, 3),
          'FatherID' = c(NA, NA, 2, 2, NA, NA, 6, 6, 6, 4, 8),
          'isProband' = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0),
          'CurAge' = c(85, 85, 50, 51, 85, 85, 40, 42, 42, 25, 26),
          'isAffBC' = c(1, 0, 1, rep(0, 8)),
          'isAffOC' = c(0, 0, 1, rep(0, 8)),
          'AgeBC' = c(50, NA, 40, rep(NA, 8)),
          'AgeOC' = c(NA, NA, 45, rep(NA, 8)),
          'isDead' = rep(0, 11),
          'race' = rep('All_Races', 11),
          'riskmod' = rep(NA, 11),
          'interAge' = rep(NA, 11),
          'Twins' = c(rep(0, 7), c(1, 1, 0, 0)),
          'BRCA1' = rep(NA, 11),
          'BRCA2' = rep(NA, 11),
          'ER' = rep(NA, 11),
          'CK5.6' = rep(NA, 11),
          'PR' = rep(NA, 11),
          'HER2' = rep(NA, 11),
          'Ancestry' = rep('nonAJ', 11)
)
print(errfam1)
#>    ID Sex MotherID FatherID isProband
#> 1   1   0       NA       NA         0
#> 2   2   1       NA       NA         0
#> 3   3   0        1        2         0
#> 4   4   1        1        2         0
#> 5   5   0       NA       NA         0
#> 6   6   1       NA       NA         0
#> 7   7   0        5        6         0
#> 8   8   1        5        6         0
#> 9   9   1        5        6         0
#> 10 10   0        7        4         1
#> 11 11   0        3        8         0
#>    CurAge isAffBC isAffOC AgeBC AgeOC
#> 1      85       1       0    50    NA
#> 2      85       0       0    NA    NA
#> 3      50       1       1    40    45
#> 4      51       0       0    NA    NA
#> 5      85       0       0    NA    NA
#> 6      85       0       0    NA    NA
#> 7      40       0       0    NA    NA
#> 8      42       0       0    NA    NA
#> 9      42       0       0    NA    NA
#> 10     25       0       0    NA    NA
#> 11     26       0       0    NA    NA
#>    isDead      race riskmod interAge
#> 1       0 All_Races      NA       NA
#> 2       0 All_Races      NA       NA
#> 3       0 All_Races      NA       NA
#> 4       0 All_Races      NA       NA
#> 5       0 All_Races      NA       NA
#> 6       0 All_Races      NA       NA
#> 7       0 All_Races      NA       NA
#> 8       0 All_Races      NA       NA
#> 9       0 All_Races      NA       NA
#> 10      0 All_Races      NA       NA
#> 11      0 All_Races      NA       NA
#>    Twins BRCA1 BRCA2 ER CK5.6 PR HER2
#> 1      0    NA    NA NA    NA NA   NA
#> 2      0    NA    NA NA    NA NA   NA
#> 3      0    NA    NA NA    NA NA   NA
#> 4      0    NA    NA NA    NA NA   NA
#> 5      0    NA    NA NA    NA NA   NA
#> 6      0    NA    NA NA    NA NA   NA
#> 7      0    NA    NA NA    NA NA   NA
#> 8      1    NA    NA NA    NA NA   NA
#> 9      1    NA    NA NA    NA NA   NA
#> 10     0    NA    NA NA    NA NA   NA
#> 11     0    NA    NA NA    NA NA   NA
#>    Ancestry
#> 1     nonAJ
#> 2     nonAJ
#> 3     nonAJ
#> 4     nonAJ
#> 5     nonAJ
#> 6     nonAJ
#> 7     nonAJ
#> 8     nonAJ
#> 9     nonAJ
#> 10    nonAJ
#> 11    nonAJ
```

This pedigree contains a loop:

Sibling Relationship:

Individual 3 and Individual 4 are siblings because they share the same
parents (`MotherID = 1` and `FatherID = 2`). Individual 7 and Individual
8 are siblings because they share the same parents (`MotherID = 5` and
`FatherID = 6`). Marriages Between Sibling Pairs:

Individual 3 (sibling 1) is married to Individual 8 (sibling 2), and
their daughter is Individual 11. Individual 4 (sibling 1) is married to
Individual 7 (sibling 2), and their daughter is Individual 10. The Loop:

To handle this, set the breakloop parameter to TRUE in the Fam3PRO
function. This will automatically detect and resolve loops in the
pedigree:

These marriages result in a loop because Individual 3 and 4 (siblings)
marry into Individual 7 and 8’s family, who are also siblings. This
creates a circular ancestry between these families.

``` r
# Use the breakloop functionality to handle loops in the pedigree
out5 <- Fam3PRO(
  pedigree = errfam1,
  model_spec = "PanPRO22",
  breakloop = TRUE
)
#> Brain, Colorectal, Endometrial, Gastric, Kidney, Leukemia, Melanoma, Osteosarcoma, Pancreas, Prostate, Small Intestine, Soft Tissue Sarcoma, Thyroid, Urinary Bladder, Hepatobiliary, Contralateral cancer(s) not in pedigree, so they will be removed from the model specification.
#> Your model has 2 cancers - Breast, Ovarian and 22 genes - ATM_hetero_anyPV, BARD1_hetero_anyPV, BRCA1_hetero_anyPV, BRCA2_hetero_anyPV, BRIP1_hetero_anyPV, CDH1_hetero_anyPV, CDK4_hetero_anyPV, CDKN2A[P16]_hetero_anyPV, EPCAM_hetero_anyPV, MLH1_hetero_anyPV, MSH2_hetero_anyPV, MSH6_hetero_anyPV, MUTYH_hetero_anyPV, MUTYH_homo_anyPV, PALB2_hetero_anyPV, PMS2_hetero_anyPV, PTEN_hetero_anyPV, RAD51C_hetero_anyPV, RAD51D_hetero_anyPV, STK11_hetero_anyPV, TP53_hetero_anyPV.
#> Setting max.mut to 2.
#> Warning: There is at least one loop in
#> the pedigree.
#> Warning: We break a loop by creating a
#> loop breaker ID 12, who is a clone of
#> ID 8. The FatherID of ID 11 is now
#> replaced by ID 12.
#> Warning: Mother ID -999 cannot be
#> found in pedigree, forcing it to NA.
#> Warning: Father ID -999 cannot be
#> found in pedigree, forcing it to NA.
#> Warning: FatherID conflict, twin
#> labelled 1 is removed.
#> Warning: MotherID conflict, twin
#> labelled 1 is removed.
#> Warning: Twins are assumed monozygotic
#> but race conflict for twin label 1.
#> Forcing them to default values.
#> Warning: Twins are assumed monozygotic
#> but Ancestry conflict for twin label
#> 1. Forcing them to default values.
#> Riskmods that are NA will be removed
#> Germline testing results for BRCA1 are assumed to be for default variant BRCA1_hetero_anyPV.
#> Germline testing results for BRCA2 are assumed to be for default variant BRCA2_hetero_anyPV.
```

``` r

# Display the posterior probabilities for the proband
print(out5$posterior.prob)
#> $`10`
#>                                            genes
#> 1                                     noncarrier
#> 2                               ATM_hetero_anyPV
#> 3                             BARD1_hetero_anyPV
#> 4                             BRCA1_hetero_anyPV
#> 5                             BRCA2_hetero_anyPV
#> 6                             BRIP1_hetero_anyPV
#> 7                              CDH1_hetero_anyPV
#> 8                              CDK4_hetero_anyPV
#> 9                       CDKN2A[P16]_hetero_anyPV
#> 10                            EPCAM_hetero_anyPV
#> 11                             MLH1_hetero_anyPV
#> 12                             MSH2_hetero_anyPV
#> 13                             MSH6_hetero_anyPV
#> 14                            MUTYH_hetero_anyPV
#> 15                              MUTYH_homo_anyPV
#> 16                            PALB2_hetero_anyPV
#> 17                             PMS2_hetero_anyPV
#> 18                             PTEN_hetero_anyPV
#> 19                           RAD51C_hetero_anyPV
#> 20                           RAD51D_hetero_anyPV
#> 21                            STK11_hetero_anyPV
#> 22                             TP53_hetero_anyPV
#> 23           ATM_hetero_anyPV.BARD1_hetero_anyPV
#> 24           ATM_hetero_anyPV.BRCA1_hetero_anyPV
#> 25         BARD1_hetero_anyPV.BRCA1_hetero_anyPV
#> 26           ATM_hetero_anyPV.BRCA2_hetero_anyPV
#> 27         BARD1_hetero_anyPV.BRCA2_hetero_anyPV
#> 28         BRCA1_hetero_anyPV.BRCA2_hetero_anyPV
#> 29           ATM_hetero_anyPV.BRIP1_hetero_anyPV
#> 30         BARD1_hetero_anyPV.BRIP1_hetero_anyPV
#> 31         BRCA1_hetero_anyPV.BRIP1_hetero_anyPV
#> 32         BRCA2_hetero_anyPV.BRIP1_hetero_anyPV
#> 33            ATM_hetero_anyPV.CDH1_hetero_anyPV
#> 34          BARD1_hetero_anyPV.CDH1_hetero_anyPV
#> 35          BRCA1_hetero_anyPV.CDH1_hetero_anyPV
#> 36          BRCA2_hetero_anyPV.CDH1_hetero_anyPV
#> 37          BRIP1_hetero_anyPV.CDH1_hetero_anyPV
#> 38            ATM_hetero_anyPV.CDK4_hetero_anyPV
#> 39          BARD1_hetero_anyPV.CDK4_hetero_anyPV
#> 40          BRCA1_hetero_anyPV.CDK4_hetero_anyPV
#> 41          BRCA2_hetero_anyPV.CDK4_hetero_anyPV
#> 42          BRIP1_hetero_anyPV.CDK4_hetero_anyPV
#> 43           CDH1_hetero_anyPV.CDK4_hetero_anyPV
#> 44     ATM_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 45   BARD1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 46   BRCA1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 47   BRCA2_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 48   BRIP1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 49    CDH1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 50    CDK4_hetero_anyPV.CDKN2A[P16]_hetero_anyPV
#> 51           ATM_hetero_anyPV.EPCAM_hetero_anyPV
#> 52         BARD1_hetero_anyPV.EPCAM_hetero_anyPV
#> 53         BRCA1_hetero_anyPV.EPCAM_hetero_anyPV
#> 54         BRCA2_hetero_anyPV.EPCAM_hetero_anyPV
#> 55         BRIP1_hetero_anyPV.EPCAM_hetero_anyPV
#> 56          CDH1_hetero_anyPV.EPCAM_hetero_anyPV
#> 57          CDK4_hetero_anyPV.EPCAM_hetero_anyPV
#> 58   CDKN2A[P16]_hetero_anyPV.EPCAM_hetero_anyPV
#> 59            ATM_hetero_anyPV.MLH1_hetero_anyPV
#> 60          BARD1_hetero_anyPV.MLH1_hetero_anyPV
#> 61          BRCA1_hetero_anyPV.MLH1_hetero_anyPV
#> 62          BRCA2_hetero_anyPV.MLH1_hetero_anyPV
#> 63          BRIP1_hetero_anyPV.MLH1_hetero_anyPV
#> 64           CDH1_hetero_anyPV.MLH1_hetero_anyPV
#> 65           CDK4_hetero_anyPV.MLH1_hetero_anyPV
#> 66    CDKN2A[P16]_hetero_anyPV.MLH1_hetero_anyPV
#> 67          EPCAM_hetero_anyPV.MLH1_hetero_anyPV
#> 68            ATM_hetero_anyPV.MSH2_hetero_anyPV
#> 69          BARD1_hetero_anyPV.MSH2_hetero_anyPV
#> 70          BRCA1_hetero_anyPV.MSH2_hetero_anyPV
#> 71          BRCA2_hetero_anyPV.MSH2_hetero_anyPV
#> 72          BRIP1_hetero_anyPV.MSH2_hetero_anyPV
#> 73           CDH1_hetero_anyPV.MSH2_hetero_anyPV
#> 74           CDK4_hetero_anyPV.MSH2_hetero_anyPV
#> 75    CDKN2A[P16]_hetero_anyPV.MSH2_hetero_anyPV
#> 76          EPCAM_hetero_anyPV.MSH2_hetero_anyPV
#> 77           MLH1_hetero_anyPV.MSH2_hetero_anyPV
#> 78            ATM_hetero_anyPV.MSH6_hetero_anyPV
#> 79          BARD1_hetero_anyPV.MSH6_hetero_anyPV
#> 80          BRCA1_hetero_anyPV.MSH6_hetero_anyPV
#> 81          BRCA2_hetero_anyPV.MSH6_hetero_anyPV
#> 82          BRIP1_hetero_anyPV.MSH6_hetero_anyPV
#> 83           CDH1_hetero_anyPV.MSH6_hetero_anyPV
#> 84           CDK4_hetero_anyPV.MSH6_hetero_anyPV
#> 85    CDKN2A[P16]_hetero_anyPV.MSH6_hetero_anyPV
#> 86          EPCAM_hetero_anyPV.MSH6_hetero_anyPV
#> 87           MLH1_hetero_anyPV.MSH6_hetero_anyPV
#> 88           MSH2_hetero_anyPV.MSH6_hetero_anyPV
#> 89           ATM_hetero_anyPV.MUTYH_hetero_anyPV
#> 90         BARD1_hetero_anyPV.MUTYH_hetero_anyPV
#> 91         BRCA1_hetero_anyPV.MUTYH_hetero_anyPV
#> 92         BRCA2_hetero_anyPV.MUTYH_hetero_anyPV
#> 93         BRIP1_hetero_anyPV.MUTYH_hetero_anyPV
#> 94          CDH1_hetero_anyPV.MUTYH_hetero_anyPV
#> 95          CDK4_hetero_anyPV.MUTYH_hetero_anyPV
#> 96   CDKN2A[P16]_hetero_anyPV.MUTYH_hetero_anyPV
#> 97         EPCAM_hetero_anyPV.MUTYH_hetero_anyPV
#> 98          MLH1_hetero_anyPV.MUTYH_hetero_anyPV
#> 99          MSH2_hetero_anyPV.MUTYH_hetero_anyPV
#> 100         MSH6_hetero_anyPV.MUTYH_hetero_anyPV
#> 101            ATM_hetero_anyPV.MUTYH_homo_anyPV
#> 102          BARD1_hetero_anyPV.MUTYH_homo_anyPV
#> 103          BRCA1_hetero_anyPV.MUTYH_homo_anyPV
#> 104          BRCA2_hetero_anyPV.MUTYH_homo_anyPV
#> 105          BRIP1_hetero_anyPV.MUTYH_homo_anyPV
#> 106           CDH1_hetero_anyPV.MUTYH_homo_anyPV
#> 107           CDK4_hetero_anyPV.MUTYH_homo_anyPV
#> 108    CDKN2A[P16]_hetero_anyPV.MUTYH_homo_anyPV
#> 109          EPCAM_hetero_anyPV.MUTYH_homo_anyPV
#> 110           MLH1_hetero_anyPV.MUTYH_homo_anyPV
#> 111           MSH2_hetero_anyPV.MUTYH_homo_anyPV
#> 112           MSH6_hetero_anyPV.MUTYH_homo_anyPV
#> 113          ATM_hetero_anyPV.PALB2_hetero_anyPV
#> 114        BARD1_hetero_anyPV.PALB2_hetero_anyPV
#> 115        BRCA1_hetero_anyPV.PALB2_hetero_anyPV
#> 116        BRCA2_hetero_anyPV.PALB2_hetero_anyPV
#> 117        BRIP1_hetero_anyPV.PALB2_hetero_anyPV
#> 118         CDH1_hetero_anyPV.PALB2_hetero_anyPV
#> 119         CDK4_hetero_anyPV.PALB2_hetero_anyPV
#> 120  CDKN2A[P16]_hetero_anyPV.PALB2_hetero_anyPV
#> 121        EPCAM_hetero_anyPV.PALB2_hetero_anyPV
#> 122         MLH1_hetero_anyPV.PALB2_hetero_anyPV
#> 123         MSH2_hetero_anyPV.PALB2_hetero_anyPV
#> 124         MSH6_hetero_anyPV.PALB2_hetero_anyPV
#> 125        MUTYH_hetero_anyPV.PALB2_hetero_anyPV
#> 126          MUTYH_homo_anyPV.PALB2_hetero_anyPV
#> 127           ATM_hetero_anyPV.PMS2_hetero_anyPV
#> 128         BARD1_hetero_anyPV.PMS2_hetero_anyPV
#> 129         BRCA1_hetero_anyPV.PMS2_hetero_anyPV
#> 130         BRCA2_hetero_anyPV.PMS2_hetero_anyPV
#> 131         BRIP1_hetero_anyPV.PMS2_hetero_anyPV
#> 132          CDH1_hetero_anyPV.PMS2_hetero_anyPV
#> 133          CDK4_hetero_anyPV.PMS2_hetero_anyPV
#> 134   CDKN2A[P16]_hetero_anyPV.PMS2_hetero_anyPV
#> 135         EPCAM_hetero_anyPV.PMS2_hetero_anyPV
#> 136          MLH1_hetero_anyPV.PMS2_hetero_anyPV
#> 137          MSH2_hetero_anyPV.PMS2_hetero_anyPV
#> 138          MSH6_hetero_anyPV.PMS2_hetero_anyPV
#> 139         MUTYH_hetero_anyPV.PMS2_hetero_anyPV
#> 140           MUTYH_homo_anyPV.PMS2_hetero_anyPV
#> 141         PALB2_hetero_anyPV.PMS2_hetero_anyPV
#> 142           ATM_hetero_anyPV.PTEN_hetero_anyPV
#> 143         BARD1_hetero_anyPV.PTEN_hetero_anyPV
#> 144         BRCA1_hetero_anyPV.PTEN_hetero_anyPV
#> 145         BRCA2_hetero_anyPV.PTEN_hetero_anyPV
#> 146         BRIP1_hetero_anyPV.PTEN_hetero_anyPV
#> 147          CDH1_hetero_anyPV.PTEN_hetero_anyPV
#> 148          CDK4_hetero_anyPV.PTEN_hetero_anyPV
#> 149   CDKN2A[P16]_hetero_anyPV.PTEN_hetero_anyPV
#> 150         EPCAM_hetero_anyPV.PTEN_hetero_anyPV
#> 151          MLH1_hetero_anyPV.PTEN_hetero_anyPV
#> 152          MSH2_hetero_anyPV.PTEN_hetero_anyPV
#> 153          MSH6_hetero_anyPV.PTEN_hetero_anyPV
#> 154         MUTYH_hetero_anyPV.PTEN_hetero_anyPV
#> 155           MUTYH_homo_anyPV.PTEN_hetero_anyPV
#> 156         PALB2_hetero_anyPV.PTEN_hetero_anyPV
#> 157          PMS2_hetero_anyPV.PTEN_hetero_anyPV
#> 158         ATM_hetero_anyPV.RAD51C_hetero_anyPV
#> 159       BARD1_hetero_anyPV.RAD51C_hetero_anyPV
#> 160       BRCA1_hetero_anyPV.RAD51C_hetero_anyPV
#> 161       BRCA2_hetero_anyPV.RAD51C_hetero_anyPV
#> 162       BRIP1_hetero_anyPV.RAD51C_hetero_anyPV
#> 163        CDH1_hetero_anyPV.RAD51C_hetero_anyPV
#> 164        CDK4_hetero_anyPV.RAD51C_hetero_anyPV
#> 165 CDKN2A[P16]_hetero_anyPV.RAD51C_hetero_anyPV
#> 166       EPCAM_hetero_anyPV.RAD51C_hetero_anyPV
#> 167        MLH1_hetero_anyPV.RAD51C_hetero_anyPV
#> 168        MSH2_hetero_anyPV.RAD51C_hetero_anyPV
#> 169        MSH6_hetero_anyPV.RAD51C_hetero_anyPV
#> 170       MUTYH_hetero_anyPV.RAD51C_hetero_anyPV
#> 171         MUTYH_homo_anyPV.RAD51C_hetero_anyPV
#> 172       PALB2_hetero_anyPV.RAD51C_hetero_anyPV
#> 173        PMS2_hetero_anyPV.RAD51C_hetero_anyPV
#> 174        PTEN_hetero_anyPV.RAD51C_hetero_anyPV
#> 175         ATM_hetero_anyPV.RAD51D_hetero_anyPV
#> 176       BARD1_hetero_anyPV.RAD51D_hetero_anyPV
#> 177       BRCA1_hetero_anyPV.RAD51D_hetero_anyPV
#> 178       BRCA2_hetero_anyPV.RAD51D_hetero_anyPV
#> 179       BRIP1_hetero_anyPV.RAD51D_hetero_anyPV
#> 180        CDH1_hetero_anyPV.RAD51D_hetero_anyPV
#> 181        CDK4_hetero_anyPV.RAD51D_hetero_anyPV
#> 182 CDKN2A[P16]_hetero_anyPV.RAD51D_hetero_anyPV
#> 183       EPCAM_hetero_anyPV.RAD51D_hetero_anyPV
#> 184        MLH1_hetero_anyPV.RAD51D_hetero_anyPV
#> 185        MSH2_hetero_anyPV.RAD51D_hetero_anyPV
#> 186        MSH6_hetero_anyPV.RAD51D_hetero_anyPV
#> 187       MUTYH_hetero_anyPV.RAD51D_hetero_anyPV
#> 188         MUTYH_homo_anyPV.RAD51D_hetero_anyPV
#> 189       PALB2_hetero_anyPV.RAD51D_hetero_anyPV
#> 190        PMS2_hetero_anyPV.RAD51D_hetero_anyPV
#> 191        PTEN_hetero_anyPV.RAD51D_hetero_anyPV
#> 192      RAD51C_hetero_anyPV.RAD51D_hetero_anyPV
#> 193          ATM_hetero_anyPV.STK11_hetero_anyPV
#> 194        BARD1_hetero_anyPV.STK11_hetero_anyPV
#> 195        BRCA1_hetero_anyPV.STK11_hetero_anyPV
#> 196        BRCA2_hetero_anyPV.STK11_hetero_anyPV
#> 197        BRIP1_hetero_anyPV.STK11_hetero_anyPV
#> 198         CDH1_hetero_anyPV.STK11_hetero_anyPV
#> 199         CDK4_hetero_anyPV.STK11_hetero_anyPV
#> 200  CDKN2A[P16]_hetero_anyPV.STK11_hetero_anyPV
#> 201        EPCAM_hetero_anyPV.STK11_hetero_anyPV
#> 202         MLH1_hetero_anyPV.STK11_hetero_anyPV
#> 203         MSH2_hetero_anyPV.STK11_hetero_anyPV
#> 204         MSH6_hetero_anyPV.STK11_hetero_anyPV
#> 205        MUTYH_hetero_anyPV.STK11_hetero_anyPV
#> 206          MUTYH_homo_anyPV.STK11_hetero_anyPV
#> 207        PALB2_hetero_anyPV.STK11_hetero_anyPV
#> 208         PMS2_hetero_anyPV.STK11_hetero_anyPV
#> 209         PTEN_hetero_anyPV.STK11_hetero_anyPV
#> 210       RAD51C_hetero_anyPV.STK11_hetero_anyPV
#> 211       RAD51D_hetero_anyPV.STK11_hetero_anyPV
#> 212           ATM_hetero_anyPV.TP53_hetero_anyPV
#> 213         BARD1_hetero_anyPV.TP53_hetero_anyPV
#> 214         BRCA1_hetero_anyPV.TP53_hetero_anyPV
#> 215         BRCA2_hetero_anyPV.TP53_hetero_anyPV
#> 216         BRIP1_hetero_anyPV.TP53_hetero_anyPV
#> 217          CDH1_hetero_anyPV.TP53_hetero_anyPV
#> 218          CDK4_hetero_anyPV.TP53_hetero_anyPV
#> 219   CDKN2A[P16]_hetero_anyPV.TP53_hetero_anyPV
#> 220         EPCAM_hetero_anyPV.TP53_hetero_anyPV
#> 221          MLH1_hetero_anyPV.TP53_hetero_anyPV
#> 222          MSH2_hetero_anyPV.TP53_hetero_anyPV
#> 223          MSH6_hetero_anyPV.TP53_hetero_anyPV
#> 224         MUTYH_hetero_anyPV.TP53_hetero_anyPV
#> 225           MUTYH_homo_anyPV.TP53_hetero_anyPV
#> 226         PALB2_hetero_anyPV.TP53_hetero_anyPV
#> 227          PMS2_hetero_anyPV.TP53_hetero_anyPV
#> 228          PTEN_hetero_anyPV.TP53_hetero_anyPV
#> 229        RAD51C_hetero_anyPV.TP53_hetero_anyPV
#> 230        RAD51D_hetero_anyPV.TP53_hetero_anyPV
#> 231         STK11_hetero_anyPV.TP53_hetero_anyPV
#>         estimate lower upper
#> 1   7.624136e-01    NA    NA
#> 2   3.461389e-03    NA    NA
#> 3   9.259396e-04    NA    NA
#> 4   1.464976e-01    NA    NA
#> 5   6.762476e-02    NA    NA
#> 6   1.156202e-03    NA    NA
#> 7   5.133061e-04    NA    NA
#> 8   3.425555e-04    NA    NA
#> 9   2.463726e-04    NA    NA
#> 10  1.730167e-05    NA    NA
#> 11  1.576015e-03    NA    NA
#> 12  2.806009e-03    NA    NA
#> 13  7.910932e-04    NA    NA
#> 14  1.244091e-04    NA    NA
#> 15  5.030604e-09    NA    NA
#> 16  1.410533e-03    NA    NA
#> 17  3.052427e-03    NA    NA
#> 18  3.337558e-04    NA    NA
#> 19  7.941763e-04    NA    NA
#> 20  5.334781e-04    NA    NA
#> 21  1.941439e-05    NA    NA
#> 22  1.698898e-03    NA    NA
#> 23  4.312939e-06    NA    NA
#> 24  5.555098e-04    NA    NA
#> 25  1.057237e-04    NA    NA
#> 26  2.536154e-04    NA    NA
#> 27  4.926235e-05    NA    NA
#> 28  2.759701e-04    NA    NA
#> 29  5.606866e-06    NA    NA
#> 30  1.398363e-06    NA    NA
#> 31  1.689549e-04    NA    NA
#> 32  8.086425e-05    NA    NA
#> 33  2.237369e-06    NA    NA
#> 34  6.709910e-07    NA    NA
#> 35  4.507988e-05    NA    NA
#> 36  2.054617e-05    NA    NA
#> 37  1.003205e-06    NA    NA
#> 38  1.455787e-06    NA    NA
#> 39  4.106160e-07    NA    NA
#> 40  6.251749e-05    NA    NA
#> 41  2.916668e-05    NA    NA
#> 42  5.070764e-07    NA    NA
#> 43  2.356653e-07    NA    NA
#> 44  1.046987e-06    NA    NA
#> 45  2.953097e-07    NA    NA
#> 46  4.496172e-05    NA    NA
#> 47  2.097623e-05    NA    NA
#> 48  3.646833e-07    NA    NA
#> 49  1.694871e-07    NA    NA
#> 50  1.001374e-07    NA    NA
#> 51  7.351819e-08    NA    NA
#> 52  2.073609e-08    NA    NA
#> 53  3.157118e-06    NA    NA
#> 54  1.472899e-06    NA    NA
#> 55  2.560746e-08    NA    NA
#> 56  1.190102e-08    NA    NA
#> 57  7.031558e-09    NA    NA
#> 58  5.057035e-09    NA    NA
#> 59  9.229109e-06    NA    NA
#> 60  1.934554e-06    NA    NA
#> 61  1.335006e-04    NA    NA
#> 62  6.974518e-05    NA    NA
#> 63  2.345118e-06    NA    NA
#> 64  1.843339e-06    NA    NA
#> 65  7.759458e-07    NA    NA
#> 66  5.580475e-07    NA    NA
#> 67  3.918460e-08    NA    NA
#> 68  1.778840e-05    NA    NA
#> 69  3.463443e-06    NA    NA
#> 70  1.529291e-04    NA    NA
#> 71  8.873987e-05    NA    NA
#> 72  4.172967e-06    NA    NA
#> 73  3.694987e-06    NA    NA
#> 74  1.452565e-06    NA    NA
#> 75  1.044659e-06    NA    NA
#> 76  7.335274e-08    NA    NA
#> 77  4.025877e-06    NA    NA
#> 78  4.850819e-06    NA    NA
#> 79  9.716889e-07    NA    NA
#> 80  5.243692e-05    NA    NA
#> 81  2.890392e-05    NA    NA
#> 82  1.173377e-06    NA    NA
#> 83  9.932500e-07    NA    NA
#> 84  4.005399e-07    NA    NA
#> 85  2.880614e-07    NA    NA
#> 86  2.022684e-08    NA    NA
#> 87  1.192729e-06    NA    NA
#> 88  1.763248e-06    NA    NA
#> 89  5.287098e-07    NA    NA
#> 90  1.491151e-07    NA    NA
#> 91  2.270028e-05    NA    NA
#> 92  1.059058e-05    NA    NA
#> 93  1.841452e-07    NA    NA
#> 94  8.559281e-08    NA    NA
#> 95  5.056592e-08    NA    NA
#> 96  3.636657e-08    NA    NA
#> 97  2.553627e-09    NA    NA
#> 98  2.817685e-07    NA    NA
#> 99  5.274556e-07    NA    NA
#> 100 1.454454e-07    NA    NA
#> 101 2.006027e-11    NA    NA
#> 102 5.950231e-12    NA    NA
#> 103 8.757320e-10    NA    NA
#> 104 4.127041e-10    NA    NA
#> 105 7.267738e-12    NA    NA
#> 106 3.523457e-12    NA    NA
#> 107 1.849566e-12    NA    NA
#> 108 1.330127e-12    NA    NA
#> 109 9.338942e-14    NA    NA
#> 110 1.224531e-11    NA    NA
#> 111 2.376323e-11    NA    NA
#> 112 6.451874e-12    NA    NA
#> 113 6.082213e-06    NA    NA
#> 114 1.798720e-06    NA    NA
#> 115 1.758624e-04    NA    NA
#> 116 7.718146e-05    NA    NA
#> 117 2.539364e-06    NA    NA
#> 118 7.969237e-07    NA    NA
#> 119 6.186355e-07    NA    NA
#> 120 4.449153e-07    NA    NA
#> 121 3.124122e-08    NA    NA
#> 122 4.494181e-06    NA    NA
#> 123 8.897794e-06    NA    NA
#> 124 2.403318e-06    NA    NA
#> 125 2.246817e-07    NA    NA
#> 126 8.882748e-12    NA    NA
#> 127 1.800367e-05    NA    NA
#> 128 3.753935e-06    NA    NA
#> 129 2.526641e-04    NA    NA
#> 130 1.326693e-04    NA    NA
#> 131 4.547694e-06    NA    NA
#> 132 3.608100e-06    NA    NA
#> 133 1.509979e-06    NA    NA
#> 134 1.085952e-06    NA    NA
#> 135 7.625261e-08    NA    NA
#> 136 4.949640e-06    NA    NA
#> 137 7.700013e-06    NA    NA
#> 138 2.286724e-06    NA    NA
#> 139 5.483164e-07    NA    NA
#> 140 2.391346e-11    NA    NA
#> 141 8.786885e-06    NA    NA
#> 142 1.439670e-06    NA    NA
#> 143 4.243674e-07    NA    NA
#> 144 4.519985e-05    NA    NA
#> 145 2.006748e-05    NA    NA
#> 146 5.835222e-07    NA    NA
#> 147 1.986731e-07    NA    NA
#> 148 1.440751e-07    NA    NA
#> 149 1.036172e-07    NA    NA
#> 150 7.275845e-09    NA    NA
#> 151 1.017994e-06    NA    NA
#> 152 2.004726e-06    NA    NA
#> 153 5.423916e-07    NA    NA
#> 154 5.232631e-08    NA    NA
#> 155 2.038967e-12    NA    NA
#> 156 5.583700e-07    NA    NA
#> 157 1.989520e-06    NA    NA
#> 158 3.879906e-06    NA    NA
#> 159 9.606622e-07    NA    NA
#> 160 1.141743e-04    NA    NA
#> 161 5.475536e-05    NA    NA
#> 162 1.177506e-06    NA    NA
#> 163 6.977696e-07    NA    NA
#> 164 3.498050e-07    NA    NA
#> 165 2.515755e-07    NA    NA
#> 166 1.766521e-08    NA    NA
#> 167 1.598196e-06    NA    NA
#> 168 2.833223e-06    NA    NA
#> 169 7.978332e-07    NA    NA
#> 170 1.270317e-07    NA    NA
#> 171 5.033512e-12    NA    NA
#> 172 1.763070e-06    NA    NA
#> 173 3.098471e-06    NA    NA
#> 174 4.048581e-07    NA    NA
#> 175 2.916457e-06    NA    NA
#> 176 6.493608e-07    NA    NA
#> 177 5.726963e-05    NA    NA
#> 178 2.865402e-05    NA    NA
#> 179 7.902311e-07    NA    NA
#> 180 5.628045e-07    NA    NA
#> 181 2.513058e-07    NA    NA
#> 182 1.807355e-07    NA    NA
#> 183 1.269084e-08    NA    NA
#> 184 9.451866e-07    NA    NA
#> 185 1.563816e-06    NA    NA
#> 186 4.527254e-07    NA    NA
#> 187 9.125831e-08    NA    NA
#> 188 3.832056e-12    NA    NA
#> 189 1.388567e-06    NA    NA
#> 190 1.824283e-06    NA    NA
#> 191 3.158106e-07    NA    NA
#> 192 5.400505e-07    NA    NA
#> 193 8.401344e-08    NA    NA
#> 194 2.518525e-08    NA    NA
#> 195 1.574561e-06    NA    NA
#> 196 7.060318e-07    NA    NA
#> 197 3.850159e-08    NA    NA
#> 198 8.905321e-09    NA    NA
#> 199 8.974078e-09    NA    NA
#> 200 6.454024e-09    NA    NA
#> 201 4.531867e-10    NA    NA
#> 202 7.127972e-08    NA    NA
#> 203 1.432773e-07    NA    NA
#> 204 3.848542e-08    NA    NA
#> 205 3.259355e-09    NA    NA
#> 206 1.349220e-13    NA    NA
#> 207 2.921167e-08    NA    NA
#> 208 1.395515e-07    NA    NA
#> 209 7.340178e-09    NA    NA
#> 210 2.678959e-08    NA    NA
#> 211 2.172222e-08    NA    NA
#> 212 7.359712e-06    NA    NA
#> 213 2.225195e-06    NA    NA
#> 214 1.036824e-04    NA    NA
#> 215 4.830424e-05    NA    NA
#> 216 3.484707e-06    NA    NA
#> 217 6.940644e-07    NA    NA
#> 218 7.990325e-07    NA    NA
#> 219 5.746522e-07    NA    NA
#> 220 4.035074e-08    NA    NA
#> 221 6.553497e-06    NA    NA
#> 222 1.324191e-05    NA    NA
#> 223 3.550557e-06    NA    NA
#> 224 2.902086e-07    NA    NA
#> 225 1.218943e-11    NA    NA
#> 226 2.482935e-06    NA    NA
#> 227 1.283626e-05    NA    NA
#> 228 6.321402e-07    NA    NA
#> 229 2.426578e-06    NA    NA
#> 230 1.988122e-06    NA    NA
#> 231 2.486771e-08    NA    NA
```
