## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(Fam3PRO)

## ----err_fam_1_definition-----------------------------------------------------
# err_fam_1 data.frame set up example

# Set up basic required columns
err_fam_1 <- data.frame("ID" = 1:10)
err_fam_1$Sex <- c(0, 1, 0, 1, 0, 1, 0, 1, 0, 1)

err_fam_1$MotherID <- c(NA, NA, NA, NA, 1, 1, 3, 3, 7, 5)
err_fam_1$FatherID <- c(NA, NA, NA, NA, 2, 2, 4, 4, 6, 8)

err_fam_1$isProband <- 0
err_fam_1[err_fam_1$ID == 7, "isProband"] <- 1

err_fam_1$CurAge <- c(92, 93, NA, 87, 55, 59, 60, 62, 32, 33)

err_fam_1$isDead <- 0
err_fam_1[err_fam_1$ID %in% c(1, 4), "isDead"] <- 1

err_fam_1$Twins <- 0

err_fam_1$riskmod <- list(character(0))
err_fam_1[err_fam_1$ID == 8, "riskmod"] <- "Oophorectomy"
err_fam_1$interAge <- NA
err_fam_1[err_fam_1$ID == 8, "interAge"] <- 40

err_fam_1$race <- "Black"
err_fam_1$Ancestry <- "nonAJ"

# Set up cancers
# Pancreatic cancer
err_fam_1$isAffPANC <- 0
err_fam_1$AgePANC <- NA
err_fam_1[err_fam_1$ID == 2, "isAffPANC"] <- 1
err_fam_1[err_fam_1$ID == 2, "AgePANC"] <- 50

# Breast cancer
err_fam_1$isAffBC <- 0
err_fam_1$AgeBC <- NA
err_fam_1[err_fam_1$ID == 8, "isAffBC"] <- 1
err_fam_1[err_fam_1$ID == 8, "AgeBC"] <- 35

## ----error = TRUE-------------------------------------------------------------
Fam3PRO(err_fam_1, cancers = c("Breast", "Pancreas"), genes = c("MSH2", "TP53"))

