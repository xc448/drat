## usethis namespace: start
#' @useDynLib Fam3PRO, .registration = TRUE
## usethis namespace: end
NULL
