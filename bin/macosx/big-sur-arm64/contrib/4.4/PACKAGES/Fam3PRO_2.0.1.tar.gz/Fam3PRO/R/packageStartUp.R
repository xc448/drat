.onAttach <- function(libname, pkgname) {
  version <- "2.0.0"
  art <- c(
"
  _______                _______ _______ _______ _______ 
 |   _   .---.-.--------|   _   |   _   |   _   |   _   |
 |.  1___|  _  |        |___|   |.  1   |.  l   |.  |   |
 |.  __) |___._|__|__|__|_(__   |.  ____|.  _   |.  |   |
 |:  |                  |:  1   |:  |   |:  |   |:  1   |
 |::.|                  |::.. . |::.|   |::.|:. |::.. . |
 `---'                  `-------`---'   `--- ---`-------'
")
  yellow <- crayon::yellow
  msg <- sprintf("Fam3PRO version: %s", version)
  packageStartupMessage("Welcome to the Fam3PRO package, by the BayesMendel Lab!")
  packageStartupMessage(msg)
  packageStartupMessage(paste(yellow(art), "\n"))
}
