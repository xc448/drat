
<!-- README.md is generated from README.Rmd. Please edit that file -->

# Fam3PRO R package

The Fam3PRO R package extends the BayesMendel R package to
multi-syndrome, multi-gene Mendelian risk prediction modeling.

## Installation


### Install Fam3PRO from source

If you are installing Fam3PRO from source and running Linux, enter the

following into the terminal:

    R CMD INSTALL Fam3PRO_X.X.X.tar.gz

For Windows, enter the following into your R console:

    install.packages("[your Fam3PRO file path]/Fam3PRO_X.X.X.zip", repos = NULL, type = "source")

where `X.X.X` corresponds to the version number you have downloaded.

## Quick-start guide

This following is a quick-start guide for basic usage of the `Fam3PRO`
package. For greater detail on model options, please refer to the other
vignettes and documentation, e.g
`vignette("building-pedigrees", package = "Fam3PRO")` or
`help(Fam3PRO)`.

The primary function in the package is the eponymous `Fam3PRO`, which
outputs the posterior carrier probabilities and future risk of cancer of
one or more probands, based on the user-supplied `pedigree` and model
specification (either `model_spec` or explicit specification of `genes`
and `cancers`).

``` r
library(Fam3PRO)
```

### Pedigree

The user must specify the `pedigree` argument as a data frame with the
following columns:

- `ID`: A numeric value; ID for each individual. There should not be any
  duplicated entries.
- `Sex`: A numeric value; `0` for female and `1` for male. Missing
  entries are not currently supported.
- `MotherID`: A numeric value; unique ID for someone’s mother.
- `FatherID`: A numeric value; unique ID for someone’s father.
- `isProband`: A numeric value; `1` if someone is a proband, `0`
  otherwise. This will be overridden by the `proband` argument in
  `Fam3PRO`, if it is specified. At least one proband should be
  specified by either the `isProband` column or `proband`. Multiple
  probands are supported.
- `CurAge`: A numeric value; the age of censoring (current age if the
  person is alive or age of death if the person is dead). Ages ranging
  from `1` to `94` are allowed.
- `isAffX`: A numeric value; the affection status of cancer `X`, where
  `X` is a `short` cancer code (see below). Affection status should be
  encoded as `1` if the individual was diagnosed, `0`otherwise. Missing
  entries are not currently supported.
- `AgeX`: A numeric value; the age of diagnosis for cancer `X`, where
  `X` is a `short` cancer code (see below). Ages ranging from `1` to
  `94` are allowed. If the individual was not diagnosed for a given
  cancer, their affection age should be encoded as `NA` and will be
  ignored otherwise.
- `isDead`: A numeric value; `1` if someone is dead, `0` otherwise.
  Missing entries are assumed to be `0`.
- `race`: A character string; expected values are `"All_Races"`,
  `"AIAN"` (American Indian and Alaska Native), `"Asian"`, `"Black"`,
  `"White"`, `"Hispanic"`, `"WH"` (white Hispanic), and `"WNH"`
  (non-white Hispanic) (see `Fam3PRO:::RACE_TYPES`). Asian-Pacific
  Islanders should be encoded as `"Asian"`. Race information will be
  used to select the cancer and death by other causes penetrances used
  in the model. Missing entries are recoded as the `unknown.race`
  argument, which defaults to `Fam3PRO:::UNKNOWN_RACE`.
- `Ancestry`: A character string; expected values are `"AJ"`, `"nonAJ"`,
  and `"Italian"` (see `Fam3PRO:::ANCESTRY_TYPES`). Ancestry
  information will be used to select the allele frequencies used in the
  model. Missing entries are recoded as the `unknown.ancestry` argument,
  which defaults to `Fam3PRO:::UNKNOWN_ANCESTRY`.
- `Twins`: A numeric value; `0` for non-identical/single births, `1` for
  the first set of identical twins/multiple births in the family, `2`
  for the second set, etc. Missing entries are assumed to be `0`.
- Prophylactic surgical history columns: as of Fam3PRO v1.1.0, there
  are two ways to encode prophylactic surgical history for mastectomies,
  hysterectomies, and oophorectomies which are explained below. These
  preventative interventions will be used to modify the cancer
  penetrances for breast, endometrial, and ovarian cancer, respectively.
  Note that in order to be considered prophylactic, mastectomies and
  oophorectomies must have been bilateral.
  - The first method has been utilized since the initial release of
    Fam3PRO and uses two list type columns:
    - `riskmod`: A character list; expected values are `"Mastectomy"`,
      `"Hysterectomy"`, and `"Oophorectomy"` (see
      `data.frame(Fam3PRO:::RISKMODS)`).
    - `interAge`: A numeric list; the age of intervention for each risk
      modifier in `riskmod`. For example,
      `riskmod = list("Mastectomy", "Hysterectomy")` and
      `interAge = {45, 60}` indicates that the individual had a
      mastectomy at age 45 and a hysterectomy at age 60. Unknown surgery
      ages should be `NA`.
  - The second method, which is only compatible with Fam3PRO v1.1.0 or
    higher, uses six different numeric columns to replace the `riskmod`
    and `interAge` list type columns. This newer method makes sharing
    and storing pedigrees as .csv files easier because list type columns
    are not compatible with .csv files. The naming conventions for the
    six new columns are `riskmodX` (3 columns) and `interAgeX` (3
    columns), where “X” is one of the 3 abbreviated surgery names
    `"Mast"`, `"Ooph"`, or `"Hyst"`:
    - `riskmodX` A binary value; `1` if the surgery occurred and `0`
      otherwise.
    - `interAgeX` A numeric value; the age of the corresponding
      intervention for `riskmodX`. For example, if `riskmodMast = 1` and
      `interAgeMast = 45` the individual had a bilateral prophylactic
      mastectomy at age 45. Unknown surgery ages should be coded as
      `NA`.
- There can be optional columns for germline testing results
  (e.g. `BRCA1`, `MLH1`) or tumor marker testing results. `ER`, `PR`,
  `CK14`, `CK5.6` and `HER2` are tumor markers associated with breast
  cancer that will modify the likelihood of phenotypes associated with
  `BRCA1` and `BRCA2`. `MSI` is a tumor marker for colorectal cancer
  that will modify the likelihoods associated with `MLH1`, `MSH2` `MSH6`
  and `PMS2`. For each of these optional columns, positive results
  should be coded as `1`, negative results should be coded as `0`, and
  unknown results should be coded as `NA`.
- There are optional columns related to breast cancer which provide more
  accurate estimates for contralateral breast cancer risk. These columns
  are:
  - `FirstBCType`: Breast cancer type of the first primary breast
    cancer. The only options are `Invasive` for pure invasive and
    `Invasive_DCIS` for mixed invasive and DCIS. There is no option for
    pure DCIS (see “Additional Notes” section). Use `NA` if no first
    primary breast cancer or unknown type.
  - `AntiEstrogen`: Anti-estrogen therapy used to treat first primary
    breast cancer. The options are `0` for no, `1` for yes, and `NA` for
    unknown or for those never diagnosed with breast cancer.
  - `HRPreneoplasia`: History of high risk preneoplasia (ie atypical
    hyperplasia or LCIS). The options are `0` for no, `1` for yes, and
    `NA` for unknown or for those never diagnosed with breast cancer.
  - `BreastDensity`: BI-RADS breast density descriptor. The options are
    the letters `a` through `d`. `a` = almost entirely fatty, `b` =
    scattered areas of fibroglandular density, `c` = heterogeneously
    dense, and `d` = extremely dense. If the breast density is unknown,
    use `NA`.
  - `FirstBCTumorSize`: Size category of the first primary breast cancer
    tumor. The only options are `"T0/T1/T2"`, `"T3/T4"`, `"Tis"`. Use
    `NA` for unknown tumor size or if there was no first primary breast
    cancer.

To represent a cancer in `pedigree`, we need to use `short` cancer
codes:

``` r
data.frame(Fam3PRO:::CANCER_NAME_MAP)
#>    short                long
#> 1    BRA               Brain
#> 2     BC              Breast
#> 3    COL          Colorectal
#> 4   ENDO         Endometrial
#> 5    GAS             Gastric
#> 6    KID              Kidney
#> 7   LEUK            Leukemia
#> 8   MELA            Melanoma
#> 9     OC             Ovarian
#> 10   OST        Osteosarcoma
#> 11  PANC            Pancreas
#> 12  PROS            Prostate
#> 13    SI     Small Intestine
#> 14   STS Soft Tissue Sarcoma
#> 15   THY             Thyroid
#> 16    UB     Urinary Bladder
#> 17   HEP       Hepatobiliary
#> 18   CBC       Contralateral
```

For example, `BC` is the `short` name that maps to `Breast`, so breast
cancer affection status and age of diagnosis should be recorded as
columns named `isAffBC` and `AgeBC`.

Note `Contralateral` indicates contralateral breast cancer (`CBC`).

Unknown values in `pedigree` should be explicitly coded as `NA`.

Before computing anything, the `Fam3PRO` function will check the
validity and structural consistency of `pedigree`. Errors will be
corrected when possible, or the function will halt with an informative
error message if not.

The `Fam3PRO` package comes with several sample pedigrees, each of
which contains family history information. For example, `err_fam_1` is a
pedigree that will fail the validity checks and `test_fam_1` is a valid
pedigree that contains 19 relatives and family history for breast and
ovarian cancer:

``` r
head(test_fam_1)
#>   ID Sex MotherID FatherID isProband CurAge isAffBC isAffOC AgeBC
#> 1  1   0       NA       NA         0     93       1       0    65
#> 2  2   1       NA       NA         0     80       0       0    NA
#> 3  3   0        1        2         0     72       1       1    40
#> 4  4   1        1        2         0     65       0       0    NA
#> 5  5   1        1        2         0     65       0       0    NA
#> 6  6   0        1        2         1     55       0       0    NA
#>   AgeOC isDead      race      riskmod interAge Twins BRCA1 BRCA2
#> 1    NA      1 All_Races                           0    NA    NA
#> 2    NA      1 All_Races                           0     1     0
#> 3    NA      0 All_Races   Mastectomy       28     0    NA    NA
#> 4    NA      1 All_Races                           1     1    NA
#> 5    NA      0 All_Races                           1    NA    NA
#> 6    NA      0 All_Races Hysterectomy       48     0    NA    NA
#>   ER CK5.6 CK14 PR HER2 Ancestry
#> 1 NA    NA   NA NA   NA    nonAJ
#> 2 NA    NA   NA NA   NA    nonAJ
#> 3 NA    NA   NA NA   NA       AJ
#> 4 NA    NA   NA NA   NA    nonAJ
#> 5 NA    NA   NA NA   NA    nonAJ
#> 6  0    NA   NA NA   NA    nonAJ
```

For more information on the sample pedigrees, see their individual help
pages. For an example of building a pedigree, see the vignette on
“Building Fam3PRO Pedigrees”.

### Model specification

There are a few ways to specify the model to be run by `Fam3PRO`. The
first is to pass a character string to `model_spec` that indicates a
pre-specified model. Available options are:

``` r
names(Fam3PRO:::MODELPARAMS)
#> [1] "PanPRO11" "PanPRO22"
```

The genes and cancers that these models specify can be found by
accessing the named list element in `Fam3PRO:::MODELPARAMS`. For
example, the 22 genes and 17 cancers specified by `"PanPRO22"` are:

``` r
Fam3PRO:::MODELPARAMS$PanPRO22
#> $GENES
#>  [1] "ATM"    "BARD1"  "BRCA1"  "BRCA2"  "BRIP1"  "CDH1"  
#>  [7] "CDK4"   "CDKN2A" "CHEK2"  "EPCAM"  "MLH1"   "MSH2"  
#> [13] "MSH6"   "MUTYH"  "NBN"    "PALB2"  "PMS2"   "PTEN"  
#> [19] "RAD51C" "RAD51D" "STK11"  "TP53"  
#> 
#> $CANCERS
#>  [1] "Brain"               "Breast"             
#>  [3] "Colorectal"          "Endometrial"        
#>  [5] "Gastric"             "Kidney"             
#>  [7] "Leukemia"            "Melanoma"           
#>  [9] "Ovarian"             "Osteosarcoma"       
#> [11] "Pancreas"            "Prostate"           
#> [13] "Small Intestine"     "Soft Tissue Sarcoma"
#> [15] "Thyroid"             "Urinary Bladder"    
#> [17] "Hepatobiliary"       "Contralateral"
```

For convenience, the `Fam3PRO` package exports wrapper functions for
all of the pre-specified models: `Fam3PRO11`, and `Fam3PRO22`.

Alternatively, the user can explicitly pass in genes to the `genes`
argument and cancers to the `cancers` argument. If the inputs conflict
with each other, `genes` and `cancers` will override the `model_spec`
specification. Available genes are:

``` r

Fam3PRO:::GENE_TYPES
#>  [1] "ATM"    "BARD1"  "BRCA1"  "BRCA2"  "BRIP1"  "CDH1"  
#>  [7] "CDK4"   "CDKN2A" "CHEK2"  "EPCAM"  "MLH1"   "MSH2"  
#> [13] "MSH6"   "MUTYH"  "NBN"    "PALB2"  "PMS2"   "PTEN"  
#> [19] "RAD51C" "RAD51D" "STK11"  "TP53"
```

Available cancers are:

``` r
Fam3PRO:::CANCER_TYPES
#>  [1] "Brain"               "Breast"              "Colorectal"         
#>  [4] "Endometrial"         "Gastric"             "Kidney"             
#>  [7] "Leukemia"            "Melanoma"            "Ovarian"            
#> [10] "Osteosarcoma"        "Pancreas"            "Prostate"           
#> [13] "Small Intestine"     "Soft Tissue Sarcoma" "Thyroid"            
#> [16] "Urinary Bladder"     "Hepatobiliary"       "Contralateral"

```

Therefore, it is equivalent to run:

- `Fam3PRO(pedigree, model_spec = "PanPRO22", ...)`
- `Fam3PRO22(pedigree, ...)`
- `Fam3PRO(pedigree, genes = Fam3PRO:::MODELPARAMS$PanPRO22$GENES, cancers = Fam3PRO:::MODELPARAMS$PanPRO22$CANCERS, ...)`

By default, `Fam3PRO` without any user-specified `model_spec`, `genes`,
or `cancers` will run `Fam3PRO22`, so it is also equivalent in this
case to simply write `Fam3PRO(pedigree, ...)`. Cancers for which no
family history is available in the pedigree will be dropped from the
model specification, under the default settings.

### Additional notes

- The `Fam3PRO` function pulls model parameters, including mutation
  allele frequencies and cancer penetrances, from the `database`
  argument. The internal `Fam3PRODataBase` is used by default, but
  users can override it by passing in their own database.

- The optional `proband` argument allows the user to specify the IDs for
  one or more probands for whom carrier probabilities and future risk
  should be estimated, overriding the contents of the `isProband` column
  in `pedigree`. If `proband = "All"`, the results for all individuals
  in the pedigree will be calculated.

- The `Fam3PRO` function returns a list with two elements,
  `posterior.prob` and `future.risk`. By default, `Fam3PRO` imputes 20
  iterations of missing ages (`impute.missing.ages = TRUE` and
  `iterations = 20`). When missing ages are multiply imputed,
  `posterior.prob` and `future.risk` report the average and range of the
  results from these imputations.

- The `max.mut` argument sets the maximum number of simultaneous
  mutations allowed. By default, `max.mut` will be set to `2` when
  `pedigree` has 30 or fewer members and `1` when `pedigree` exceeds 30
  members. For example, if `max.mut = 2`, a model that includes MLH1,
  MSH2, and MSH6 will estimate the carrier probability of being a
  carrier of both MLH1 and MSH2 (or of both MLH1 and MSH6, or of both
  MSH2 and MSH6), but not of being a carrier of MLH1, MSH2, and MSH6
  simultaneously. Choosing a large value for `max.mut`, especially when
  there is a large number of genes in the model, may result in slow
  performance.

- The `age.by` argument determines the fixed age intervals for the
  future risk calculations. By default, `age.by = 5`, so if the
  proband’s current age is 30, future risk will be calculated at ages
  35, 40, 45, etc.

- All breast cancers are assumed to be invasive or mixed invasive and
  DCIS. Pure DCIS breast cancers are not compatible with Fam3PRO.

### Example usage

The following example demonstrates how to fit a custom model to the
test_fam_1 pedigree using Fam3PRO. In this example, we specify a set of
genes and cancers to estimate the posterior carrier probabilities and
future risk for the proband (the individual with ID 6, as identified in
test_fam_1 where isProband == 1).

``` r
out1 <- Fam3PRO(
  pedigree = test_fam_1, 
  genes = c("BRCA1", "BRCA2"),       
  cancers = c("Breast", "Ovarian")  
)
#> Your model has 2 cancers - Breast, Ovarian and 2 genes - BRCA1_hetero_anyPV, BRCA2_hetero_anyPV.
#> Setting max.mut to 2.
#> ID 6,29 has tumor marker testing results but is unaffected for relevant cancer, so testing will be ignored.
#> Germline testing results for BRCA1 are assumed to be for default variant BRCA1_hetero_anyPV.
#> Germline testing results for BRCA2 are assumed to be for default variant BRCA2_hetero_anyPV.
#> ID 3 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 10 's race has been changed to All_Races to meet hereditary consistency.
#> ID 9 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 16,17 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 29,30 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 33,34 's race has been changed to All_Races to meet hereditary consistency.
#> ID 33,34 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 6's lower and upper bounds for the probability of carrying any pathogenic variant are (0.30539, 0.30544).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

``` r

# Display the results
print(out1)
#> $posterior.prob
#> $posterior.prob$`6`
#>                                   genes     estimate        lower
#> 1                            noncarrier 0.6945917127 0.6945597677
#> 2                    BRCA1_hetero_anyPV 0.3042379832 0.3042239757
#> 3                    BRCA2_hetero_anyPV 0.0008244515 0.0008041947
#> 4 BRCA1_hetero_anyPV.BRCA2_hetero_anyPV 0.0003458526 0.0003373554
#>          upper
#> 1 0.6946116976
#> 2 0.3042467523
#> 3 0.0008568245
#> 4 0.0003594321
#> 
#> 
#> $future.risk
#> $future.risk$`6`
#> $future.risk$`6`$Breast
#>   ByAge   estimate      lower      upper
#> 1    60 0.04683603 0.04683248 0.04684169
#> 2    65 0.09299212 0.09298578 0.09300225
#> 3    70 0.13677404 0.13676562 0.13678748
#> 4    75 0.17505519 0.17504529 0.17507101
#> 5    80 0.20623683 0.20622582 0.20625442
#> 6    85 0.22914480 0.22913300 0.22916366
#> 7    90 0.24223350 0.24222129 0.24225303
#> 
#> $future.risk$`6`$Ovarian
#>   ByAge   estimate      lower      upper
#> 1    60 0.03585963 0.03585849 0.03586145
#> 2    65 0.07157810 0.07157567 0.07158199
#> 3    70 0.10420462 0.10420089 0.10421058
#> 4    75 0.13183601 0.13183112 0.13184383
#> 5    80 0.15459669 0.15459089 0.15460597
#> 6    85 0.17112517 0.17111879 0.17113537
#> 7    90 0.17888222 0.17887561 0.17889279
```

The `visRisk` function provides interactive visualizations for exploring
the proband(s)’s carrier probabilities and future risk estimates
returned by `Fam3PRO`. For example,

``` r
visRisk(out1)
```

<figure>
<img src="man/figures/ans2.png" alt="vis_risk" />
<figcaption aria-hidden="true">vis_risk</figcaption>
</figure>

## Example: Using the `Fam3PRO` Function with `use.mult.variants`

The `Fam3PRO` function is a powerful tool for calculating cancer risk
based on family pedigree information. In some cases, individuals may
carry multiple genetic variants within the same gene (e.g., BRCA1,
BRCA2). By default, the model only considers a single variant per gene.
However, you can set the parameter `use.mult.variants = TRUE` to include
all available variants for more detailed risk assessments.

The following example demonstrates how to use the `Fam3PRO` function
with `use.mult.variants = TRUE`. This will allow the model to consider
multiple variants within the specified genes, providing a more
comprehensive risk estimate.

``` r
out2 <- Fam3PRO(
  pedigree = test_fam_1, 
  genes = c("BRCA1", "BRCA2"),       
  cancers = c("Breast", "Ovarian"),
  use.mult.variants = TRUE
)
#> Your model has 2 cancers - Breast, Ovarian and 2 genes - BRCA1_hetero_BCCR, BRCA1_hetero_OCCR, BRCA1_hetero_other, BRCA2_hetero_BCCR, BRCA2_hetero_OCCR, BRCA2_hetero_other, including 2 genes with multiple variants - BRCA1, BRCA2.
#> Setting max.mut to 2.
#> ID 6,29 has tumor marker testing results but is unaffected for relevant cancer, so testing will be ignored.
#> Germline testing results for BRCA1 are assumed to be for default variant BRCA1_hetero_anyPV.
#> Germline testing results for BRCA2 are assumed to be for default variant BRCA2_hetero_anyPV.
#> ID 3 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 10 's race has been changed to All_Races to meet hereditary consistency.
#> ID 9 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 16,17 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 29,30 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 33,34 's race has been changed to All_Races to meet hereditary consistency.
#> ID 33,34 's Ancestry has been changed to nonAJ to meet hereditary consistency.
#> ID 6's lower and upper bounds for the probability of carrying any pathogenic variant are (0.13332, 0.24218).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

``` r

# Display the results
print(out2)
#> $posterior.prob
#> $posterior.prob$`6`
#>                                    genes     estimate
#> 1                             noncarrier 7.777147e-01
#> 2                      BRCA1_hetero_BCCR 4.961821e-02
#> 3                      BRCA1_hetero_OCCR 1.688975e-02
#> 4                     BRCA1_hetero_other 7.123692e-02
#> 5                      BRCA2_hetero_BCCR 1.625629e-02
#> 6                      BRCA2_hetero_OCCR 2.956648e-02
#> 7                     BRCA2_hetero_other 3.856081e-02
#> 8    BRCA1_hetero_BCCR.BRCA2_hetero_BCCR 1.238089e-05
#> 9    BRCA1_hetero_OCCR.BRCA2_hetero_BCCR 5.039648e-06
#> 10  BRCA1_hetero_other.BRCA2_hetero_BCCR 1.910509e-05
#> 11   BRCA1_hetero_BCCR.BRCA2_hetero_OCCR 1.734155e-05
#> 12   BRCA1_hetero_OCCR.BRCA2_hetero_OCCR 6.663725e-06
#> 13  BRCA1_hetero_other.BRCA2_hetero_OCCR 2.613476e-05
#> 14  BRCA1_hetero_BCCR.BRCA2_hetero_other 2.396041e-05
#> 15  BRCA1_hetero_OCCR.BRCA2_hetero_other 9.551973e-06
#> 16 BRCA1_hetero_other.BRCA2_hetero_other 3.666057e-05
#>           lower        upper
#> 1  7.578157e-01 8.666835e-01
#> 2  3.225014e-02 6.015791e-02
#> 3  1.124970e-02 2.208940e-02
#> 4  4.784076e-02 8.884784e-02
#> 5  7.581124e-03 2.227227e-02
#> 6  1.496569e-02 3.808505e-02
#> 7  1.858924e-02 5.144002e-02
#> 8  7.949389e-06 1.454487e-05
#> 9  3.523702e-06 6.386012e-06
#> 10 1.266197e-05 2.308785e-05
#> 11 1.151037e-05 2.076242e-05
#> 12 4.670263e-06 8.578664e-06
#> 13 1.787470e-05 3.215025e-05
#> 14 1.555825e-05 2.828398e-05
#> 15 6.740402e-06 1.214591e-05
#> 16 2.455263e-05 4.449435e-05
#> 
#> 
#> $future.risk
#> $future.risk$`6`
#> $future.risk$`6`$Breast
#>   ByAge   estimate      lower      upper
#> 1    60 0.04055865 0.03023922 0.04253974
#> 2    65 0.08138251 0.06180715 0.08527476
#> 3    70 0.12170572 0.09423496 0.12728761
#> 4    75 0.15907053 0.12497295 0.16604556
#> 5    80 0.19185034 0.15161285 0.20011070
#> 6    85 0.21944794 0.17316164 0.22899418
#> 7    90 0.24080467 0.18894139 0.25154899
#> 
#> $future.risk$`6`$Ovarian
#>   ByAge   estimate      lower      upper
#> 1    60 0.02048635 0.01339041 0.02392209
#> 2    65 0.04215148 0.02745999 0.04892385
#> 3    70 0.06343350 0.04121916 0.07320056
#> 4    75 0.08323828 0.05399959 0.09555073
#> 5    80 0.10154175 0.06581962 0.11612214
#> 6    85 0.11757284 0.07616304 0.13418416
#> 7    90 0.12887026 0.08346186 0.14692768
```

``` r
visRisk(out2)
```

<figure>
<img src="man/figures/ans3.png" alt="vis_risk" />
<figcaption aria-hidden="true">vis_risk</figcaption>
</figure>

`Fam3PRO11` runs an 11 gene, 11 cancer model. `test_fam_2` is a more
complex pedigree with 25 relatives and information on endometrial,
pancreatic, and small intestine cancer. By default, the cancers that are
not included in the pedigree will be dropped from the model
specification. Carrier probabilities will therefore be estimated based
on family history of endometrial, pancreatic, and small intestine
cancer; future risk estimates will only be given for these three
cancers.

``` r
out3 <- Fam3PRO11(pedigree = test_fam_2)
#> Brain, Breast, Colorectal, Gastric, Kidney, Melanoma, Ovarian, Prostate, Contralateral cancer(s) not in pedigree, so they will be removed from the model specification.
#> Your model has 3 cancers - Endometrial, Pancreas, Small Intestine and 11 genes - BRCA1_hetero_anyPV, BRCA2_hetero_anyPV, ATM_hetero_anyPV, PALB2_hetero_anyPV, EPCAM_hetero_anyPV, PMS2_hetero_anyPV, MLH1_hetero_anyPV, MSH2_hetero_anyPV, MSH6_hetero_anyPV, CDKN2A[P16]_hetero_anyPV.
#> Setting max.mut to 2.
#> ID 12's lower and upper bounds for the probability of carrying any pathogenic variant are (0.18359, 0.26504).
#> ID 19's lower and upper bounds for the probability of carrying any pathogenic variant are (0.10457, 0.1466).
#> ID 21's lower and upper bounds for the probability of carrying any pathogenic variant are (0.04486, 0.04815).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

`out3` contains results for the three probands specified by the
`isProband` column in `fam25`. We can extract the results for a specific
proband, e.g. the one with `ID = 12`.

``` r
head(out3$posterior.prob$`12`)
#>                genes     estimate        lower        upper
#> 1         noncarrier 7.865484e-01 7.349587e-01 8.164098e-01
#> 2 BRCA1_hetero_anyPV 9.710081e-04 9.505986e-04 9.927828e-04
#> 3 BRCA2_hetero_anyPV 1.095702e-03 1.071286e-03 1.121795e-03
#> 4   ATM_hetero_anyPV 3.119200e-03 3.053583e-03 3.188884e-03
#> 5 PALB2_hetero_anyPV 9.248660e-04 9.042598e-04 9.469008e-04
#> 6 EPCAM_hetero_anyPV 1.850897e-05 1.813198e-05 1.888302e-05
```

``` r

out3$future.risk$`12`
#> $Endometrial
#>    ByAge   estimate       lower      upper
#> 1     49 0.01142447 0.009729645 0.01444102
#> 2     54 0.03260254 0.027726733 0.04128998
#> 3     59 0.06046886 0.051574640 0.07629808
#> 4     64 0.08304290 0.071393643 0.10368059
#> 5     69 0.09483359 0.082475206 0.11655261
#> 6     74 0.10150689 0.089197231 0.12297034
#> 7     79 0.10611686 0.093902117 0.12729764
#> 8     84 0.10921176 0.097063039 0.13020582
#> 9     89 0.11092063 0.098812030 0.13180937
#> 10    94 0.11178311 0.099701252 0.13261526
#> 
#> $Pancreas
#>    ByAge     estimate        lower        upper
#> 1     49 0.0005139685 0.0004638275 0.0006043847
#> 2     54 0.0013459773 0.0012242108 0.0015651886
#> 3     59 0.0027573403 0.0025190302 0.0031864078
#> 4     64 0.0049793237 0.0045574439 0.0057395155
#> 5     69 0.0080808216 0.0074157746 0.0092796518
#> 6     74 0.0116471047 0.0107407032 0.0132805488
#> 7     79 0.0152545605 0.0141746497 0.0171987082
#> 8     84 0.0183679705 0.0172068843 0.0204561311
#> 9     89 0.0206937153 0.0195187429 0.0228054203
#> 10    94 0.0222370446 0.0210897349 0.0242995090
#> 
#> $`Small Intestine`
#>    ByAge    estimate       lower       upper
#> 1     49 0.001447946 0.001204529 0.001887493
#> 2     54 0.003248391 0.002718037 0.004202854
#> 3     59 0.005300019 0.004465702 0.006792199
#> 4     64 0.007512243 0.006365159 0.009554215
#> 5     69 0.009650381 0.008213919 0.012201025
#> 6     74 0.011552878 0.009865645 0.014547235
#> 7     79 0.013002945 0.011130493 0.016330290
#> 8     84 0.014019370 0.012024273 0.017569054
#> 9     89 0.014519555 0.012475757 0.018157794
#> 10    94 0.014679913 0.012633244 0.018323690
```

Finally, we can run Fam3PRO-22 (the default for `Fam3PRO`) on
`test_fam_3`, which has 50 relatives and stores family history for the
11 cancers specified by Fam3PRO-11. Note that because there are more
than 30 relatives in `test_fam_3`, the `max.mut` argument, which sets
the maximum number of simultaneous mutations allowed, defaults to `1`
instead of `2`. We set `proband = 10`, overriding the proband
information encoded in `test_fam_3$isProband`.

``` r
out4 <- Fam3PRO(pedigree = test_fam_3, proband = 10)
#> Leukemia, Osteosarcoma, Soft Tissue Sarcoma, Thyroid, Urinary Bladder, Hepatobiliary, Contralateral cancer(s) not in pedigree, so they will be removed from the model specification.
#> Your model has 11 cancers - Brain, Breast, Colorectal, Endometrial, Gastric, Kidney, Melanoma, Ovarian, Pancreas, Prostate, Small Intestine and 22 genes - ATM_hetero_anyPV, BARD1_hetero_anyPV, BRCA1_hetero_anyPV, BRCA2_hetero_anyPV, BRIP1_hetero_anyPV, CDH1_hetero_anyPV, CDK4_hetero_anyPV, CDKN2A[P16]_hetero_anyPV, EPCAM_hetero_anyPV, MLH1_hetero_anyPV, MSH2_hetero_anyPV, MSH6_hetero_anyPV, MUTYH_hetero_anyPV, MUTYH_homo_anyPV, PALB2_hetero_anyPV, PMS2_hetero_anyPV, PTEN_hetero_anyPV, RAD51C_hetero_anyPV, RAD51D_hetero_anyPV, STK11_hetero_anyPV, TP53_hetero_anyPV.
#> Setting max.mut to 1.
#> `proband` argument does not match with "isProband" column in the pedigree, using `proband`
#> Riskmods that are NA will be removed
#> Warning: ID 14 is male but has been affected by OC; turning into
#> non-affection.
#> ID 10's lower and upper bounds for the probability of carrying any pathogenic variant are (0.92862, 0.9791).
#> The value ranges in the results are driven by the different imputed missing ages at each imputation, so please consider including more age information when possible to reduce the range widths.
```

### Example: Handling Pedigrees with Loops using breakloop

n some cases, a pedigree may contain loops (cycles), where individuals
are related in complex ways that form circular references. These loops
can complicate genetic risk calculations. The `Fam3PRO` function
includes an option to automatically detect and break loops in pedigrees
using the breakloop parameter. This example demonstrates how to use this
feature.

Consider the following pedigree (`errfam1`), which includes a loop:

``` r
errfam1 <- data.frame(
          'ID' = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11),
          'Sex' = c(0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0),
          'MotherID' = c(NA, NA, 1, 1, NA, NA, 5, 5, 5, 7, 3),
          'FatherID' = c(NA, NA, 2, 2, NA, NA, 6, 6, 6, 4, 8),
          'isProband' = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0),
          'CurAge' = c(85, 85, 50, 51, 85, 85, 40, 42, 42, 25, 26),
          'isAffBC' = c(1, 0, 1, rep(0, 8)),
          'isAffOC' = c(0, 0, 1, rep(0, 8)),
          'AgeBC' = c(50, NA, 40, rep(NA, 8)),
          'AgeOC' = c(NA, NA, 45, rep(NA, 8)),
          'isDead' = rep(0, 11),
          'race' = rep('All_Races', 11),
          'riskmod' = rep(NA, 11),
          'interAge' = rep(NA, 11),
          'Twins' = c(rep(0, 7), c(1, 1, 0, 0)),
          'BRCA1' = rep(NA, 11),
          'BRCA2' = rep(NA, 11),
          'ER' = rep(NA, 11),
          'CK5.6' = rep(NA, 11),
          'PR' = rep(NA, 11),
          'HER2' = rep(NA, 11),
          'Ancestry' = rep('nonAJ', 11)
)
print(errfam1)
#>    ID Sex MotherID FatherID isProband CurAge isAffBC isAffOC
#> 1   1   0       NA       NA         0     85       1       0
#> 2   2   1       NA       NA         0     85       0       0
#> 3   3   0        1        2         0     50       1       1
#> 4   4   1        1        2         0     51       0       0
#> 5   5   0       NA       NA         0     85       0       0
#> 6   6   1       NA       NA         0     85       0       0
#> 7   7   0        5        6         0     40       0       0
#> 8   8   1        5        6         0     42       0       0
#> 9   9   1        5        6         0     42       0       0
#> 10 10   0        7        4         1     25       0       0
#> 11 11   0        3        8         0     26       0       0
#>    AgeBC AgeOC isDead      race riskmod interAge Twins BRCA1
#> 1     50    NA      0 All_Races      NA       NA     0    NA
#> 2     NA    NA      0 All_Races      NA       NA     0    NA
#> 3     40    45      0 All_Races      NA       NA     0    NA
#> 4     NA    NA      0 All_Races      NA       NA     0    NA
#> 5     NA    NA      0 All_Races      NA       NA     0    NA
#> 6     NA    NA      0 All_Races      NA       NA     0    NA
#> 7     NA    NA      0 All_Races      NA       NA     0    NA
#> 8     NA    NA      0 All_Races      NA       NA     1    NA
#> 9     NA    NA      0 All_Races      NA       NA     1    NA
#> 10    NA    NA      0 All_Races      NA       NA     0    NA
#> 11    NA    NA      0 All_Races      NA       NA     0    NA
#>    BRCA2 ER CK5.6 PR HER2 Ancestry
#> 1     NA NA    NA NA   NA    nonAJ
#> 2     NA NA    NA NA   NA    nonAJ
#> 3     NA NA    NA NA   NA    nonAJ
#> 4     NA NA    NA NA   NA    nonAJ
#> 5     NA NA    NA NA   NA    nonAJ
#> 6     NA NA    NA NA   NA    nonAJ
#> 7     NA NA    NA NA   NA    nonAJ
#> 8     NA NA    NA NA   NA    nonAJ
#> 9     NA NA    NA NA   NA    nonAJ
#> 10    NA NA    NA NA   NA    nonAJ
#> 11    NA NA    NA NA   NA    nonAJ
```

This pedigree contains a loop:

Sibling Relationship:

Individual 3 and Individual 4 are siblings because they share the same
parents (`MotherID = 1` and `FatherID = 2`). Individual 7 and Individual
8 are siblings because they share the same parents (`MotherID = 5` and
`FatherID = 6`). Marriages Between Sibling Pairs:

To handle this, set the breakloop parameter to TRUE in the Fam3PRO
function. This will automatically detect and resolve loops in the

Individual 3 (sibling 1) is married to Individual 8 (sibling 2), and
their daughter is Individual 11. Individual 4 (sibling 1) is married to
Individual 7 (sibling 2), and their daughter is Individual 10. The Loop:

These marriages result in a loop because Individual 3 and 4 (siblings)
marry into Individual 7 and 8’s family, who are also siblings. This
creates a circular ancestry between these families. To handle this, set
the breakloop parameter to TRUE in the PanelPRO function. This will
automatically detect and resolve loops in the pedigree:

``` r
# Use the breakloop functionality to handle loops in the pedigree
out5 <- Fam3PRO(
  pedigree = errfam1,
  model_spec = "PanPRO22",
  breakloop = TRUE
)
#> Brain, Colorectal, Endometrial, Gastric, Kidney, Leukemia, Melanoma, Osteosarcoma, Pancreas, Prostate, Small Intestine, Soft Tissue Sarcoma, Thyroid, Urinary Bladder, Hepatobiliary, Contralateral cancer(s) not in pedigree, so they will be removed from the model specification.
#> Your model has 2 cancers - Breast, Ovarian and 22 genes - ATM_hetero_anyPV, BARD1_hetero_anyPV, BRCA1_hetero_anyPV, BRCA2_hetero_anyPV, BRIP1_hetero_anyPV, CDH1_hetero_anyPV, CDK4_hetero_anyPV, CDKN2A[P16]_hetero_anyPV, EPCAM_hetero_anyPV, MLH1_hetero_anyPV, MSH2_hetero_anyPV, MSH6_hetero_anyPV, MUTYH_hetero_anyPV, MUTYH_homo_anyPV, PALB2_hetero_anyPV, PMS2_hetero_anyPV, PTEN_hetero_anyPV, RAD51C_hetero_anyPV, RAD51D_hetero_anyPV, STK11_hetero_anyPV, TP53_hetero_anyPV.
#> Setting max.mut to 2.
#> Warning: There is at least one loop in the pedigree.
#> Warning: We break a loop by creating a loop breaker ID 12, who is
#> a clone of ID 8. The FatherID of ID 11 is now replaced by ID 12.
#> Warning: Mother ID -999 cannot be found in pedigree, forcing it
#> to NA.
#> Warning: Father ID -999 cannot be found in pedigree, forcing it
#> to NA.
#> Warning: FatherID conflict, twin labelled 1 is removed.
#> Warning: MotherID conflict, twin labelled 1 is removed.
#> Warning: Twins are assumed monozygotic but race conflict for twin
#> label 1. Forcing them to default values.
#> Warning: Twins are assumed monozygotic but Ancestry conflict for
#> twin label 1. Forcing them to default values.
#> Riskmods that are NA will be removed
#> Germline testing results for BRCA1 are assumed to be for default variant BRCA1_hetero_anyPV.
#> Germline testing results for BRCA2 are assumed to be for default variant BRCA2_hetero_anyPV.
```

``` r

# Display the posterior probabilities for the proband
print(out5$posterior.prob)
#> $`10`
#>                                            genes     estimate
#> 1                                     noncarrier 7.624136e-01
#> 2                               ATM_hetero_anyPV 3.461389e-03
#> 3                             BARD1_hetero_anyPV 9.259396e-04
#> 4                             BRCA1_hetero_anyPV 1.464976e-01
#> 5                             BRCA2_hetero_anyPV 6.762476e-02
#> 6                             BRIP1_hetero_anyPV 1.156202e-03
#> 7                              CDH1_hetero_anyPV 5.133061e-04
#> 8                              CDK4_hetero_anyPV 3.425555e-04
#> 9                       CDKN2A[P16]_hetero_anyPV 2.463726e-04
#> 10                            EPCAM_hetero_anyPV 1.730167e-05
#> 11                             MLH1_hetero_anyPV 1.576015e-03
#> 12                             MSH2_hetero_anyPV 2.806009e-03
#> 13                             MSH6_hetero_anyPV 7.910932e-04
#> 14                            MUTYH_hetero_anyPV 1.244091e-04
#> 15                              MUTYH_homo_anyPV 5.030604e-09
#> 16                            PALB2_hetero_anyPV 1.410533e-03
#> 17                             PMS2_hetero_anyPV 3.052427e-03
#> 18                             PTEN_hetero_anyPV 3.337558e-04
#> 19                           RAD51C_hetero_anyPV 7.941763e-04
#> 20                           RAD51D_hetero_anyPV 5.334781e-04
#> 21                            STK11_hetero_anyPV 1.941439e-05
#> 22                             TP53_hetero_anyPV 1.698898e-03
#> 23           ATM_hetero_anyPV.BARD1_hetero_anyPV 4.312939e-06
#> 24           ATM_hetero_anyPV.BRCA1_hetero_anyPV 5.555098e-04
#> 25         BARD1_hetero_anyPV.BRCA1_hetero_anyPV 1.057237e-04
#> 26           ATM_hetero_anyPV.BRCA2_hetero_anyPV 2.536154e-04
#> 27         BARD1_hetero_anyPV.BRCA2_hetero_anyPV 4.926235e-05
#> 28         BRCA1_hetero_anyPV.BRCA2_hetero_anyPV 2.759701e-04
#> 29           ATM_hetero_anyPV.BRIP1_hetero_anyPV 5.606866e-06
#> 30         BARD1_hetero_anyPV.BRIP1_hetero_anyPV 1.398363e-06
#> 31         BRCA1_hetero_anyPV.BRIP1_hetero_anyPV 1.689549e-04
#> 32         BRCA2_hetero_anyPV.BRIP1_hetero_anyPV 8.086425e-05
#> 33            ATM_hetero_anyPV.CDH1_hetero_anyPV 2.237369e-06
#> 34          BARD1_hetero_anyPV.CDH1_hetero_anyPV 6.709910e-07
#> 35          BRCA1_hetero_anyPV.CDH1_hetero_anyPV 4.507988e-05
#> 36          BRCA2_hetero_anyPV.CDH1_hetero_anyPV 2.054617e-05
#> 37          BRIP1_hetero_anyPV.CDH1_hetero_anyPV 1.003205e-06
#> 38            ATM_hetero_anyPV.CDK4_hetero_anyPV 1.455787e-06
#> 39          BARD1_hetero_anyPV.CDK4_hetero_anyPV 4.106160e-07
#> 40          BRCA1_hetero_anyPV.CDK4_hetero_anyPV 6.251749e-05
#> 41          BRCA2_hetero_anyPV.CDK4_hetero_anyPV 2.916668e-05
#> 42          BRIP1_hetero_anyPV.CDK4_hetero_anyPV 5.070764e-07
#> 43           CDH1_hetero_anyPV.CDK4_hetero_anyPV 2.356653e-07
#> 44     ATM_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 1.046987e-06
#> 45   BARD1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 2.953097e-07
#> 46   BRCA1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 4.496172e-05
#> 47   BRCA2_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 2.097623e-05
#> 48   BRIP1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 3.646833e-07
#> 49    CDH1_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 1.694871e-07
#> 50    CDK4_hetero_anyPV.CDKN2A[P16]_hetero_anyPV 1.001374e-07
#> 51           ATM_hetero_anyPV.EPCAM_hetero_anyPV 7.351819e-08
#> 52         BARD1_hetero_anyPV.EPCAM_hetero_anyPV 2.073609e-08
#> 53         BRCA1_hetero_anyPV.EPCAM_hetero_anyPV 3.157118e-06
#> 54         BRCA2_hetero_anyPV.EPCAM_hetero_anyPV 1.472899e-06
#> 55         BRIP1_hetero_anyPV.EPCAM_hetero_anyPV 2.560746e-08
#> 56          CDH1_hetero_anyPV.EPCAM_hetero_anyPV 1.190102e-08
#> 57          CDK4_hetero_anyPV.EPCAM_hetero_anyPV 7.031558e-09
#> 58   CDKN2A[P16]_hetero_anyPV.EPCAM_hetero_anyPV 5.057035e-09
#> 59            ATM_hetero_anyPV.MLH1_hetero_anyPV 9.229109e-06
#> 60          BARD1_hetero_anyPV.MLH1_hetero_anyPV 1.934554e-06
#> 61          BRCA1_hetero_anyPV.MLH1_hetero_anyPV 1.335006e-04
#> 62          BRCA2_hetero_anyPV.MLH1_hetero_anyPV 6.974518e-05
#> 63          BRIP1_hetero_anyPV.MLH1_hetero_anyPV 2.345118e-06
#> 64           CDH1_hetero_anyPV.MLH1_hetero_anyPV 1.843339e-06
#> 65           CDK4_hetero_anyPV.MLH1_hetero_anyPV 7.759458e-07
#> 66    CDKN2A[P16]_hetero_anyPV.MLH1_hetero_anyPV 5.580475e-07
#> 67          EPCAM_hetero_anyPV.MLH1_hetero_anyPV 3.918460e-08
#> 68            ATM_hetero_anyPV.MSH2_hetero_anyPV 1.778840e-05
#> 69          BARD1_hetero_anyPV.MSH2_hetero_anyPV 3.463443e-06
#> 70          BRCA1_hetero_anyPV.MSH2_hetero_anyPV 1.529291e-04
#> 71          BRCA2_hetero_anyPV.MSH2_hetero_anyPV 8.873987e-05
#> 72          BRIP1_hetero_anyPV.MSH2_hetero_anyPV 4.172967e-06
#> 73           CDH1_hetero_anyPV.MSH2_hetero_anyPV 3.694987e-06
#> 74           CDK4_hetero_anyPV.MSH2_hetero_anyPV 1.452565e-06
#> 75    CDKN2A[P16]_hetero_anyPV.MSH2_hetero_anyPV 1.044659e-06
#> 76          EPCAM_hetero_anyPV.MSH2_hetero_anyPV 7.335274e-08
#> 77           MLH1_hetero_anyPV.MSH2_hetero_anyPV 4.025877e-06
#> 78            ATM_hetero_anyPV.MSH6_hetero_anyPV 4.850819e-06
#> 79          BARD1_hetero_anyPV.MSH6_hetero_anyPV 9.716889e-07
#> 80          BRCA1_hetero_anyPV.MSH6_hetero_anyPV 5.243692e-05
#> 81          BRCA2_hetero_anyPV.MSH6_hetero_anyPV 2.890392e-05
#> 82          BRIP1_hetero_anyPV.MSH6_hetero_anyPV 1.173377e-06
#> 83           CDH1_hetero_anyPV.MSH6_hetero_anyPV 9.932500e-07
#> 84           CDK4_hetero_anyPV.MSH6_hetero_anyPV 4.005399e-07
#> 85    CDKN2A[P16]_hetero_anyPV.MSH6_hetero_anyPV 2.880614e-07
#> 86          EPCAM_hetero_anyPV.MSH6_hetero_anyPV 2.022684e-08
#> 87           MLH1_hetero_anyPV.MSH6_hetero_anyPV 1.192729e-06
#> 88           MSH2_hetero_anyPV.MSH6_hetero_anyPV 1.763248e-06
#> 89           ATM_hetero_anyPV.MUTYH_hetero_anyPV 5.287098e-07
#> 90         BARD1_hetero_anyPV.MUTYH_hetero_anyPV 1.491151e-07
#> 91         BRCA1_hetero_anyPV.MUTYH_hetero_anyPV 2.270028e-05
#> 92         BRCA2_hetero_anyPV.MUTYH_hetero_anyPV 1.059058e-05
#> 93         BRIP1_hetero_anyPV.MUTYH_hetero_anyPV 1.841452e-07
#> 94          CDH1_hetero_anyPV.MUTYH_hetero_anyPV 8.559281e-08
#> 95          CDK4_hetero_anyPV.MUTYH_hetero_anyPV 5.056592e-08
#> 96   CDKN2A[P16]_hetero_anyPV.MUTYH_hetero_anyPV 3.636657e-08
#> 97         EPCAM_hetero_anyPV.MUTYH_hetero_anyPV 2.553627e-09
#> 98          MLH1_hetero_anyPV.MUTYH_hetero_anyPV 2.817685e-07
#> 99          MSH2_hetero_anyPV.MUTYH_hetero_anyPV 5.274556e-07
#> 100         MSH6_hetero_anyPV.MUTYH_hetero_anyPV 1.454454e-07
#> 101            ATM_hetero_anyPV.MUTYH_homo_anyPV 2.006027e-11
#> 102          BARD1_hetero_anyPV.MUTYH_homo_anyPV 5.950231e-12
#> 103          BRCA1_hetero_anyPV.MUTYH_homo_anyPV 8.757320e-10
#> 104          BRCA2_hetero_anyPV.MUTYH_homo_anyPV 4.127041e-10
#> 105          BRIP1_hetero_anyPV.MUTYH_homo_anyPV 7.267738e-12
#> 106           CDH1_hetero_anyPV.MUTYH_homo_anyPV 3.523457e-12
#> 107           CDK4_hetero_anyPV.MUTYH_homo_anyPV 1.849566e-12
#> 108    CDKN2A[P16]_hetero_anyPV.MUTYH_homo_anyPV 1.330127e-12
#> 109          EPCAM_hetero_anyPV.MUTYH_homo_anyPV 9.338942e-14
#> 110           MLH1_hetero_anyPV.MUTYH_homo_anyPV 1.224531e-11
#> 111           MSH2_hetero_anyPV.MUTYH_homo_anyPV 2.376323e-11
#> 112           MSH6_hetero_anyPV.MUTYH_homo_anyPV 6.451874e-12
#> 113          ATM_hetero_anyPV.PALB2_hetero_anyPV 6.082213e-06
#> 114        BARD1_hetero_anyPV.PALB2_hetero_anyPV 1.798720e-06
#> 115        BRCA1_hetero_anyPV.PALB2_hetero_anyPV 1.758624e-04
#> 116        BRCA2_hetero_anyPV.PALB2_hetero_anyPV 7.718146e-05
#> 117        BRIP1_hetero_anyPV.PALB2_hetero_anyPV 2.539364e-06
#> 118         CDH1_hetero_anyPV.PALB2_hetero_anyPV 7.969237e-07
#> 119         CDK4_hetero_anyPV.PALB2_hetero_anyPV 6.186355e-07
#> 120  CDKN2A[P16]_hetero_anyPV.PALB2_hetero_anyPV 4.449153e-07
#> 121        EPCAM_hetero_anyPV.PALB2_hetero_anyPV 3.124122e-08
#> 122         MLH1_hetero_anyPV.PALB2_hetero_anyPV 4.494181e-06
#> 123         MSH2_hetero_anyPV.PALB2_hetero_anyPV 8.897794e-06
#> 124         MSH6_hetero_anyPV.PALB2_hetero_anyPV 2.403318e-06
#> 125        MUTYH_hetero_anyPV.PALB2_hetero_anyPV 2.246817e-07
#> 126          MUTYH_homo_anyPV.PALB2_hetero_anyPV 8.882748e-12
#> 127           ATM_hetero_anyPV.PMS2_hetero_anyPV 1.800367e-05
#> 128         BARD1_hetero_anyPV.PMS2_hetero_anyPV 3.753935e-06
#> 129         BRCA1_hetero_anyPV.PMS2_hetero_anyPV 2.526641e-04
#> 130         BRCA2_hetero_anyPV.PMS2_hetero_anyPV 1.326693e-04
#> 131         BRIP1_hetero_anyPV.PMS2_hetero_anyPV 4.547694e-06
#> 132          CDH1_hetero_anyPV.PMS2_hetero_anyPV 3.608100e-06
#> 133          CDK4_hetero_anyPV.PMS2_hetero_anyPV 1.509979e-06
#> 134   CDKN2A[P16]_hetero_anyPV.PMS2_hetero_anyPV 1.085952e-06
#> 135         EPCAM_hetero_anyPV.PMS2_hetero_anyPV 7.625261e-08
#> 136          MLH1_hetero_anyPV.PMS2_hetero_anyPV 4.949640e-06
#> 137          MSH2_hetero_anyPV.PMS2_hetero_anyPV 7.700013e-06
#> 138          MSH6_hetero_anyPV.PMS2_hetero_anyPV 2.286724e-06
#> 139         MUTYH_hetero_anyPV.PMS2_hetero_anyPV 5.483164e-07
#> 140           MUTYH_homo_anyPV.PMS2_hetero_anyPV 2.391346e-11
#> 141         PALB2_hetero_anyPV.PMS2_hetero_anyPV 8.786885e-06
#> 142           ATM_hetero_anyPV.PTEN_hetero_anyPV 1.439670e-06
#> 143         BARD1_hetero_anyPV.PTEN_hetero_anyPV 4.243674e-07
#> 144         BRCA1_hetero_anyPV.PTEN_hetero_anyPV 4.519985e-05
#> 145         BRCA2_hetero_anyPV.PTEN_hetero_anyPV 2.006748e-05
#> 146         BRIP1_hetero_anyPV.PTEN_hetero_anyPV 5.835222e-07
#> 147          CDH1_hetero_anyPV.PTEN_hetero_anyPV 1.986731e-07
#> 148          CDK4_hetero_anyPV.PTEN_hetero_anyPV 1.440751e-07
#> 149   CDKN2A[P16]_hetero_anyPV.PTEN_hetero_anyPV 1.036172e-07
#> 150         EPCAM_hetero_anyPV.PTEN_hetero_anyPV 7.275845e-09
#> 151          MLH1_hetero_anyPV.PTEN_hetero_anyPV 1.017994e-06
#> 152          MSH2_hetero_anyPV.PTEN_hetero_anyPV 2.004726e-06
#> 153          MSH6_hetero_anyPV.PTEN_hetero_anyPV 5.423916e-07
#> 154         MUTYH_hetero_anyPV.PTEN_hetero_anyPV 5.232631e-08
#> 155           MUTYH_homo_anyPV.PTEN_hetero_anyPV 2.038967e-12
#> 156         PALB2_hetero_anyPV.PTEN_hetero_anyPV 5.583700e-07
#> 157          PMS2_hetero_anyPV.PTEN_hetero_anyPV 1.989520e-06
#> 158         ATM_hetero_anyPV.RAD51C_hetero_anyPV 3.879906e-06
#> 159       BARD1_hetero_anyPV.RAD51C_hetero_anyPV 9.606622e-07
#> 160       BRCA1_hetero_anyPV.RAD51C_hetero_anyPV 1.141743e-04
#> 161       BRCA2_hetero_anyPV.RAD51C_hetero_anyPV 5.475536e-05
#> 162       BRIP1_hetero_anyPV.RAD51C_hetero_anyPV 1.177506e-06
#> 163        CDH1_hetero_anyPV.RAD51C_hetero_anyPV 6.977696e-07
#> 164        CDK4_hetero_anyPV.RAD51C_hetero_anyPV 3.498050e-07
#> 165 CDKN2A[P16]_hetero_anyPV.RAD51C_hetero_anyPV 2.515755e-07
#> 166       EPCAM_hetero_anyPV.RAD51C_hetero_anyPV 1.766521e-08
#> 167        MLH1_hetero_anyPV.RAD51C_hetero_anyPV 1.598196e-06
#> 168        MSH2_hetero_anyPV.RAD51C_hetero_anyPV 2.833223e-06
#> 169        MSH6_hetero_anyPV.RAD51C_hetero_anyPV 7.978332e-07
#> 170       MUTYH_hetero_anyPV.RAD51C_hetero_anyPV 1.270317e-07
#> 171         MUTYH_homo_anyPV.RAD51C_hetero_anyPV 5.033512e-12
#> 172       PALB2_hetero_anyPV.RAD51C_hetero_anyPV 1.763070e-06
#> 173        PMS2_hetero_anyPV.RAD51C_hetero_anyPV 3.098471e-06
#> 174        PTEN_hetero_anyPV.RAD51C_hetero_anyPV 4.048581e-07
#> 175         ATM_hetero_anyPV.RAD51D_hetero_anyPV 2.916457e-06
#> 176       BARD1_hetero_anyPV.RAD51D_hetero_anyPV 6.493608e-07
#> 177       BRCA1_hetero_anyPV.RAD51D_hetero_anyPV 5.726963e-05
#> 178       BRCA2_hetero_anyPV.RAD51D_hetero_anyPV 2.865402e-05
#> 179       BRIP1_hetero_anyPV.RAD51D_hetero_anyPV 7.902311e-07
#> 180        CDH1_hetero_anyPV.RAD51D_hetero_anyPV 5.628045e-07
#> 181        CDK4_hetero_anyPV.RAD51D_hetero_anyPV 2.513058e-07
#> 182 CDKN2A[P16]_hetero_anyPV.RAD51D_hetero_anyPV 1.807355e-07
#> 183       EPCAM_hetero_anyPV.RAD51D_hetero_anyPV 1.269084e-08
#> 184        MLH1_hetero_anyPV.RAD51D_hetero_anyPV 9.451866e-07
#> 185        MSH2_hetero_anyPV.RAD51D_hetero_anyPV 1.563816e-06
#> 186        MSH6_hetero_anyPV.RAD51D_hetero_anyPV 4.527254e-07
#> 187       MUTYH_hetero_anyPV.RAD51D_hetero_anyPV 9.125831e-08
#> 188         MUTYH_homo_anyPV.RAD51D_hetero_anyPV 3.832056e-12
#> 189       PALB2_hetero_anyPV.RAD51D_hetero_anyPV 1.388567e-06
#> 190        PMS2_hetero_anyPV.RAD51D_hetero_anyPV 1.824283e-06
#> 191        PTEN_hetero_anyPV.RAD51D_hetero_anyPV 3.158106e-07
#> 192      RAD51C_hetero_anyPV.RAD51D_hetero_anyPV 5.400505e-07
#> 193          ATM_hetero_anyPV.STK11_hetero_anyPV 8.401344e-08
#> 194        BARD1_hetero_anyPV.STK11_hetero_anyPV 2.518525e-08
#> 195        BRCA1_hetero_anyPV.STK11_hetero_anyPV 1.574561e-06
#> 196        BRCA2_hetero_anyPV.STK11_hetero_anyPV 7.060318e-07
#> 197        BRIP1_hetero_anyPV.STK11_hetero_anyPV 3.850159e-08
#> 198         CDH1_hetero_anyPV.STK11_hetero_anyPV 8.905321e-09
#> 199         CDK4_hetero_anyPV.STK11_hetero_anyPV 8.974078e-09
#> 200  CDKN2A[P16]_hetero_anyPV.STK11_hetero_anyPV 6.454024e-09
#> 201        EPCAM_hetero_anyPV.STK11_hetero_anyPV 4.531867e-10
#> 202         MLH1_hetero_anyPV.STK11_hetero_anyPV 7.127972e-08
#> 203         MSH2_hetero_anyPV.STK11_hetero_anyPV 1.432773e-07
#> 204         MSH6_hetero_anyPV.STK11_hetero_anyPV 3.848542e-08
#> 205        MUTYH_hetero_anyPV.STK11_hetero_anyPV 3.259355e-09
#> 206          MUTYH_homo_anyPV.STK11_hetero_anyPV 1.349220e-13
#> 207        PALB2_hetero_anyPV.STK11_hetero_anyPV 2.921167e-08
#> 208         PMS2_hetero_anyPV.STK11_hetero_anyPV 1.395515e-07
#> 209         PTEN_hetero_anyPV.STK11_hetero_anyPV 7.340178e-09
#> 210       RAD51C_hetero_anyPV.STK11_hetero_anyPV 2.678959e-08
#> 211       RAD51D_hetero_anyPV.STK11_hetero_anyPV 2.172222e-08
#> 212           ATM_hetero_anyPV.TP53_hetero_anyPV 7.359712e-06
#> 213         BARD1_hetero_anyPV.TP53_hetero_anyPV 2.225195e-06
#> 214         BRCA1_hetero_anyPV.TP53_hetero_anyPV 1.036824e-04
#> 215         BRCA2_hetero_anyPV.TP53_hetero_anyPV 4.830424e-05
#> 216         BRIP1_hetero_anyPV.TP53_hetero_anyPV 3.484707e-06
#> 217          CDH1_hetero_anyPV.TP53_hetero_anyPV 6.940644e-07
#> 218          CDK4_hetero_anyPV.TP53_hetero_anyPV 7.990325e-07
#> 219   CDKN2A[P16]_hetero_anyPV.TP53_hetero_anyPV 5.746522e-07
#> 220         EPCAM_hetero_anyPV.TP53_hetero_anyPV 4.035074e-08
#> 221          MLH1_hetero_anyPV.TP53_hetero_anyPV 6.553497e-06
#> 222          MSH2_hetero_anyPV.TP53_hetero_anyPV 1.324191e-05
#> 223          MSH6_hetero_anyPV.TP53_hetero_anyPV 3.550557e-06
#> 224         MUTYH_hetero_anyPV.TP53_hetero_anyPV 2.902086e-07
#> 225           MUTYH_homo_anyPV.TP53_hetero_anyPV 1.218943e-11
#> 226         PALB2_hetero_anyPV.TP53_hetero_anyPV 2.482935e-06
#> 227          PMS2_hetero_anyPV.TP53_hetero_anyPV 1.283626e-05
#> 228          PTEN_hetero_anyPV.TP53_hetero_anyPV 6.321402e-07
#> 229        RAD51C_hetero_anyPV.TP53_hetero_anyPV 2.426578e-06
#> 230        RAD51D_hetero_anyPV.TP53_hetero_anyPV 1.988122e-06
#> 231         STK11_hetero_anyPV.TP53_hetero_anyPV 2.486771e-08
#>     lower upper
#> 1      NA    NA
#> 2      NA    NA
#> 3      NA    NA
#> 4      NA    NA
#> 5      NA    NA
#> 6      NA    NA
#> 7      NA    NA
#> 8      NA    NA
#> 9      NA    NA
#> 10     NA    NA
#> 11     NA    NA
#> 12     NA    NA
#> 13     NA    NA
#> 14     NA    NA
#> 15     NA    NA
#> 16     NA    NA
#> 17     NA    NA
#> 18     NA    NA
#> 19     NA    NA
#> 20     NA    NA
#> 21     NA    NA
#> 22     NA    NA
#> 23     NA    NA
#> 24     NA    NA
#> 25     NA    NA
#> 26     NA    NA
#> 27     NA    NA
#> 28     NA    NA
#> 29     NA    NA
#> 30     NA    NA
#> 31     NA    NA
#> 32     NA    NA
#> 33     NA    NA
#> 34     NA    NA
#> 35     NA    NA
#> 36     NA    NA
#> 37     NA    NA
#> 38     NA    NA
#> 39     NA    NA
#> 40     NA    NA
#> 41     NA    NA
#> 42     NA    NA
#> 43     NA    NA
#> 44     NA    NA
#> 45     NA    NA
#> 46     NA    NA
#> 47     NA    NA
#> 48     NA    NA
#> 49     NA    NA
#> 50     NA    NA
#> 51     NA    NA
#> 52     NA    NA
#> 53     NA    NA
#> 54     NA    NA
#> 55     NA    NA
#> 56     NA    NA
#> 57     NA    NA
#> 58     NA    NA
#> 59     NA    NA
#> 60     NA    NA
#> 61     NA    NA
#> 62     NA    NA
#> 63     NA    NA
#> 64     NA    NA
#> 65     NA    NA
#> 66     NA    NA
#> 67     NA    NA
#> 68     NA    NA
#> 69     NA    NA
#> 70     NA    NA
#> 71     NA    NA
#> 72     NA    NA
#> 73     NA    NA
#> 74     NA    NA
#> 75     NA    NA
#> 76     NA    NA
#> 77     NA    NA
#> 78     NA    NA
#> 79     NA    NA
#> 80     NA    NA
#> 81     NA    NA
#> 82     NA    NA
#> 83     NA    NA
#> 84     NA    NA
#> 85     NA    NA
#> 86     NA    NA
#> 87     NA    NA
#> 88     NA    NA
#> 89     NA    NA
#> 90     NA    NA
#> 91     NA    NA
#> 92     NA    NA
#> 93     NA    NA
#> 94     NA    NA
#> 95     NA    NA
#> 96     NA    NA
#> 97     NA    NA
#> 98     NA    NA
#> 99     NA    NA
#> 100    NA    NA
#> 101    NA    NA
#> 102    NA    NA
#> 103    NA    NA
#> 104    NA    NA
#> 105    NA    NA
#> 106    NA    NA
#> 107    NA    NA
#> 108    NA    NA
#> 109    NA    NA
#> 110    NA    NA
#> 111    NA    NA
#> 112    NA    NA
#> 113    NA    NA
#> 114    NA    NA
#> 115    NA    NA
#> 116    NA    NA
#> 117    NA    NA
#> 118    NA    NA
#> 119    NA    NA
#> 120    NA    NA
#> 121    NA    NA
#> 122    NA    NA
#> 123    NA    NA
#> 124    NA    NA
#> 125    NA    NA
#> 126    NA    NA
#> 127    NA    NA
#> 128    NA    NA
#> 129    NA    NA
#> 130    NA    NA
#> 131    NA    NA
#> 132    NA    NA
#> 133    NA    NA
#> 134    NA    NA
#> 135    NA    NA
#> 136    NA    NA
#> 137    NA    NA
#> 138    NA    NA
#> 139    NA    NA
#> 140    NA    NA
#> 141    NA    NA
#> 142    NA    NA
#> 143    NA    NA
#> 144    NA    NA
#> 145    NA    NA
#> 146    NA    NA
#> 147    NA    NA
#> 148    NA    NA
#> 149    NA    NA
#> 150    NA    NA
#> 151    NA    NA
#> 152    NA    NA
#> 153    NA    NA
#> 154    NA    NA
#> 155    NA    NA
#> 156    NA    NA
#> 157    NA    NA
#> 158    NA    NA
#> 159    NA    NA
#> 160    NA    NA
#> 161    NA    NA
#> 162    NA    NA
#> 163    NA    NA
#> 164    NA    NA
#> 165    NA    NA
#> 166    NA    NA
#> 167    NA    NA
#> 168    NA    NA
#> 169    NA    NA
#> 170    NA    NA
#> 171    NA    NA
#> 172    NA    NA
#> 173    NA    NA
#> 174    NA    NA
#> 175    NA    NA
#> 176    NA    NA
#> 177    NA    NA
#> 178    NA    NA
#> 179    NA    NA
#> 180    NA    NA
#> 181    NA    NA
#> 182    NA    NA
#> 183    NA    NA
#> 184    NA    NA
#> 185    NA    NA
#> 186    NA    NA
#> 187    NA    NA
#> 188    NA    NA
#> 189    NA    NA
#> 190    NA    NA
#> 191    NA    NA
#> 192    NA    NA
#> 193    NA    NA
#> 194    NA    NA
#> 195    NA    NA
#> 196    NA    NA
#> 197    NA    NA
#> 198    NA    NA
#> 199    NA    NA
#> 200    NA    NA
#> 201    NA    NA
#> 202    NA    NA
#> 203    NA    NA
#> 204    NA    NA
#> 205    NA    NA
#> 206    NA    NA
#> 207    NA    NA
#> 208    NA    NA
#> 209    NA    NA
#> 210    NA    NA
#> 211    NA    NA
#> 212    NA    NA
#> 213    NA    NA
#> 214    NA    NA
#> 215    NA    NA
#> 216    NA    NA
#> 217    NA    NA
#> 218    NA    NA
#> 219    NA    NA
#> 220    NA    NA
#> 221    NA    NA
#> 222    NA    NA
#> 223    NA    NA
#> 224    NA    NA
#> 225    NA    NA
#> 226    NA    NA
#> 227    NA    NA
#> 228    NA    NA
#> 229    NA    NA
#> 230    NA    NA
#> 231    NA    NA
```
